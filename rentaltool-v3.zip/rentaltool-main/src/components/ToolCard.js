"use client";

import { useState } from "react";
import Link from "next/link";
import { FiMapPin, FiStar } from "react-icons/fi";
import { getGroup } from "@/lib/categories";

export default function ToolCard({ tool, distance }) {
  // Fallback image if no image exists or the image fails to load
  const fallbackImage = "https://placehold.co/400x300?text=Tool";

  const [imgSrc, setImgSrc] = useState(
    tool?.image || fallbackImage
  );

  // Get the category group information
  // Example: Industrial, Events, Tools & Equipment
  const group = getGroup(tool?.categoryGroup);

  return (
    <Link
      href={`/tools/${tool.id}`}
      className="group relative bg-white rounded-3xl shadow-lg overflow-hidden hover:shadow-2xl transition transform hover:-translate-y-1"
    >
      {/* =========================
          IMAGE SECTION
      ========================== */}
      <div className="relative h-56 overflow-hidden">
        {imgSrc ? (
          <img
            src={imgSrc}
            alt={tool.name}
            className="w-full h-full object-cover group-hover:scale-110 transition duration-500"
            onError={() => setImgSrc(fallbackImage)}
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-indigo-400 to-purple-600 flex items-center justify-center text-6xl">
            {group?.icon || "🔧"}
          </div>
        )}

        {/* =========================
            CATEGORY GROUP BADGE
        ========================== */}
        {group && (
          <span className="absolute top-3 left-3 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-semibold text-gray-800 shadow">
            {group.icon} {group.shortLabel}
          </span>
        )}

        {/* =========================
            AVAILABILITY BADGE
        ========================== */}
        {tool.isAvailable ? (
          <span className="absolute top-3 right-3 bg-green-500/95 text-white px-3 py-1 rounded-full text-xs font-semibold shadow">
            Available
          </span>
        ) : (
          <span className="absolute top-3 right-3 bg-red-600/90 text-white px-3 py-1 rounded-full text-xs font-semibold shadow">
            Unavailable
          </span>
        )}

        {/* =========================
            PRICE OVERLAY
        ========================== */}
        <div className="absolute bottom-4 left-4 text-white">
          <p className="text-2xl font-extrabold drop-shadow">
            ₹{tool.pricePerDay}
            <span className="text-sm font-medium">
              /day
            </span>
          </p>

          {tool.salePrice !== null &&
            tool.salePrice !== undefined &&
            tool.salePrice !== "" && (
              <p className="text-xs font-medium bg-white/20 backdrop-blur px-2 py-0.5 rounded-full mt-1 inline-block">
                Buy for ₹{tool.salePrice}
              </p>
            )}
        </div>

        {/* =========================
            DISTANCE / LOCATION
        ========================== */}
        {typeof distance === "number" ? (
          <span className="absolute bottom-4 right-4 bg-white/80 backdrop-blur px-2 py-1 rounded-full text-xs font-medium text-gray-800">
            📍 {distance.toFixed(1)} km
          </span>
        ) : (
          <span className="absolute bottom-4 right-4 bg-white/80 backdrop-blur px-2 py-1 rounded-full text-xs font-medium text-gray-800 max-w-[45%] truncate">
            {tool.location}
          </span>
        )}
      </div>

      {/* =========================
          CONTENT SECTION
      ========================== */}
      <div className="p-5">
        {/* Category */}
        <p className="text-xs font-medium text-indigo-600 uppercase tracking-wide truncate">
          {tool.category}
        </p>

        {/* Tool Name + Condition */}
        <div className="mt-1 flex items-center justify-between gap-2">
          <h3 className="font-bold text-lg text-gray-900 truncate">
            {tool.name}
          </h3>

          {tool.condition && (
            <span className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-full text-xs font-semibold shrink-0">
              {tool.condition}
            </span>
          )}
        </div>

        {/* Description */}
        {tool.description && (
          <p className="text-sm text-gray-500 mt-1 line-clamp-2">
            {tool.description}
          </p>
        )}

        {/* Location + Rating */}
        <div className="mt-4 flex items-center justify-between text-sm text-gray-500 gap-3">
          {/* Location */}
          <p className="flex items-center gap-1 min-w-0 truncate">
            <FiMapPin className="shrink-0" />

            {typeof distance === "number"
              ? `${distance.toFixed(1)} km away`
              : tool.location}
          </p>

          {/* Rating */}
          <p className="flex items-center gap-1 shrink-0">
            <FiStar className="text-yellow-500" />

            {typeof tool.rating === "number" && tool.rating > 0
              ? tool.rating.toFixed(1)
              : "New"}
          </p>
        </div>

        {/* =========================
            PRICE ROW
        ========================== */}
        <div className="mt-3 flex items-baseline justify-between gap-3">
          <p className="text-xl font-extrabold text-gray-900">
            ₹{tool.pricePerDay}
            <span className="text-sm font-medium text-gray-500">
              /day
            </span>
          </p>

          {tool.salePrice !== null &&
            tool.salePrice !== undefined &&
            tool.salePrice !== "" && (
              <p className="text-xs text-gray-500 whitespace-nowrap">
                or buy ₹{tool.salePrice}
              </p>
            )}
        </div>
      </div>
    </Link>
  );
}
