"use client";

import { useEffect, useMemo, useState } from "react";
import { FiChevronLeft, FiChevronRight, FiX } from "react-icons/fi";

const iso = (d) => d.toISOString().split("T")[0];
const monthStart = (d) => new Date(d.getFullYear(), d.getMonth(), 1);
const addMonths = (d, n) => new Date(d.getFullYear(), d.getMonth() + n, 1);

function isBlocked(day, ranges) {
  return ranges.some((r) => {
    const s = new Date(r.startDate); s.setHours(0, 0, 0, 0);
    const e = new Date(r.endDate); e.setHours(23, 59, 59, 999);
    return day >= s && day <= e;
  });
}

export default function AvailabilityCalendar({ toolId, isOwner }) {
  const [cursor, setCursor] = useState(monthStart(new Date()));
  const [booked, setBooked] = useState([]);
  const [manual, setManual] = useState([]);
  const [form, setForm] = useState({ startDate: "", endDate: "", reason: "" });
  const [saving, setSaving] = useState(false);

  async function load() {
    const res = await fetch(`/api/tools/${toolId}/blocked-dates`);
    if (res.ok) {
      const data = await res.json();
      setBooked(data.booked || []);
      setManual(data.manual || []);
    }
  }
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [toolId]);

  const ranges = useMemo(() => [...booked, ...manual], [booked, manual]);
  const cells = useMemo(() => {
    const n = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
    return [
      ...Array(cursor.getDay()).fill(null),
      ...Array.from({ length: n }, (_, i) => new Date(cursor.getFullYear(), cursor.getMonth(), i + 1)),
    ];
  }, [cursor]);

  async function addBlock(e) {
    e.preventDefault();
    setSaving(true);
    try {
      const res = await fetch(`/api/tools/${toolId}/blocked-dates`, {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Failed to block dates");
      setForm({ startDate: "", endDate: "", reason: "" });
      load();
    } catch (err) { alert(err.message); } finally { setSaving(false); }
  }

  async function removeBlock(id) {
    if (!confirm("Remove this blocked range?")) return;
    const res = await fetch(`/api/tools/${toolId}/blocked-dates/${id}`, { method: "DELETE" });
    if (res.ok || res.status === 204) load();
  }

  const today = new Date(); today.setHours(0, 0, 0, 0);

  return (
    <div className="border border-gray-200 rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <button onClick={() => setCursor(addMonths(cursor, -1))} aria-label="Previous month" className="p-1 text-gray-500 hover:text-gray-800"><FiChevronLeft /></button>
        <p className="font-medium text-sm">{cursor.toLocaleDateString(undefined, { month: "long", year: "numeric" })}</p>
        <button onClick={() => setCursor(addMonths(cursor, 1))} aria-label="Next month" className="p-1 text-gray-500 hover:text-gray-800"><FiChevronRight /></button>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-xs text-gray-400 mb-1">
        {["S", "M", "T", "W", "T", "F", "S"].map((d, i) => <span key={i}>{d}</span>)}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {cells.map((day, i) => day ? (
          <div key={i} title={day < today ? "Past" : isBlocked(day, ranges) ? "Unavailable" : "Available"}
            className={`aspect-square rounded text-xs flex items-center justify-center ${
              day < today ? "text-gray-300" : isBlocked(day, ranges) ? "bg-red-100 text-red-500" : "bg-green-50 text-green-700"}`}>
            {day.getDate()}
          </div>
        ) : <div key={i} />)}
      </div>
      <div className="flex gap-3 mt-3 text-xs text-gray-500">
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-green-100 border border-green-300" /> Available</span>
        <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-100 border border-red-300" /> Unavailable</span>
      </div>

      {isOwner && (
        <div className="mt-4 pt-4 border-t border-gray-100">
          <p className="text-sm font-medium mb-2">Block dates manually</p>
          <form onSubmit={addBlock} className="flex flex-wrap gap-2 items-end">
            <input type="date" required aria-label="From" value={form.startDate} onChange={(e) => setForm((p) => ({ ...p, startDate: e.target.value }))} className="px-2 py-1.5 border border-gray-300 rounded text-sm" />
            <input type="date" required aria-label="To" value={form.endDate} onChange={(e) => setForm((p) => ({ ...p, endDate: e.target.value }))} className="px-2 py-1.5 border border-gray-300 rounded text-sm" />
            <input placeholder="Reason (optional)" value={form.reason} onChange={(e) => setForm((p) => ({ ...p, reason: e.target.value }))} className="px-2 py-1.5 border border-gray-300 rounded text-sm flex-1 min-w-[120px]" />
            <button disabled={saving} className="px-3 py-1.5 bg-indigo-600 text-white rounded text-sm font-medium disabled:opacity-50">Block</button>
          </form>
          {manual.length > 0 && (
            <ul className="mt-3 space-y-1">
              {manual.map((b) => (
                <li key={b.id} className="flex items-center justify-between text-xs bg-gray-50 rounded px-2 py-1.5">
                  <span>{iso(new Date(b.startDate))} to {iso(new Date(b.endDate))}{b.reason ? ` - ${b.reason}` : ""}</span>
                  <button onClick={() => removeBlock(b.id)} aria-label="Remove block" className="text-gray-400 hover:text-red-600"><FiX className="w-3.5 h-3.5" /></button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
