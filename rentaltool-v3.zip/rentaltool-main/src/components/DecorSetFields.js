"use client";

function linesToArray(text) {
  return (text || "")
    .split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
}

function arrayToLines(arr) {
  return Array.isArray(arr) ? arr.join("\n") : "";
}

export { linesToArray, arrayToLines };

export default function DecorSetFields({ form, setForm, labelClasses, inputClasses }) {
  return (
    <div className="mt-2 space-y-4 p-4 rounded-xl border border-indigo-100 bg-indigo-50/40">
      <h3 className="font-semibold text-gray-900">Decoration Set Details</h3>

      <div>
        <label className={labelClasses}>Set Size (complete setup)</label>
        <input
          className={inputClasses}
          value={form.setSize || ""}
          onChange={(e) => setForm({ ...form, setSize: e.target.value })}
          placeholder='e.g. "10ft × 8ft backdrop", "Large hall setup"'
        />
        <p className="text-xs text-gray-500 mt-1">
          Mention the final size after full setup.
        </p>
      </div>

      <div>
        <label className={labelClasses}>Included Items (one per line)</label>
        <textarea
          className={inputClasses}
          rows={4}
          value={form.includedItemsText || ""}
          onChange={(e) => setForm({ ...form, includedItemsText: e.target.value })}
          placeholder={`Example:\nBackdrop stand\nLED string lights\nBalloon arch kit\nTape + clips`}
        />
      </div>

      <div>
        <label className={labelClasses}>Required Items to Complete Setup (one per line)</label>
        <textarea
          className={inputClasses}
          rows={4}
          value={form.requiredItemsText || ""}
          onChange={(e) => setForm({ ...form, requiredItemsText: e.target.value })}
          placeholder={`Example:\nPower extension board\nLadder\nWall hooks (if needed)\n2 people for setup`}
        />
      </div>

      <div>
        <label className={labelClasses}>Setup Instructions / Notes</label>
        <textarea
          className={inputClasses}
          rows={4}
          value={form.setupInstructions || ""}
          onChange={(e) => setForm({ ...form, setupInstructions: e.target.value })}
          placeholder="Steps, safety notes, setup time, what not to do, etc."
        />
      </div>
    </div>
  );
}
