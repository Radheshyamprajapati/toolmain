"use client";

import { useRef, useState } from "react";
import { FiUpload, FiX } from "react-icons/fi";

export default function ImageUploader({ value, onChange, label = "Photo" }) {
  const inputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");

  async function handleFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setError("");
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Upload failed");
      onChange(data.url);
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  }

  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>
      {value ? (
        <div className="relative w-40 h-40">
          <img src={value} alt="Preview" className="w-40 h-40 object-cover rounded-lg border border-gray-200" />
          <button type="button" onClick={() => onChange("")} aria-label="Remove image"
            className="absolute -top-2 -right-2 bg-white border border-gray-300 rounded-full p-1 text-gray-600 hover:text-red-600 shadow">
            <FiX className="w-4 h-4" />
          </button>
        </div>
      ) : (
        <label className="flex flex-col items-center justify-center w-40 h-40 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:border-indigo-400 text-gray-400 hover:text-indigo-500">
          <FiUpload className="w-6 h-6 mb-1" />
          <span className="text-xs">{uploading ? "Uploading..." : "Upload image"}</span>
          <input ref={inputRef} type="file" accept="image/jpeg,image/png,image/webp,image/gif"
            className="hidden" onChange={handleFile} disabled={uploading} />
        </label>
      )}
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </div>
  );
}
