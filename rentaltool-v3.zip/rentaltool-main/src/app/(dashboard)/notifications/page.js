"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    const res = await fetch("/api/notifications");
    if (res.ok) {
      setNotifications(await res.json());
    }
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  if (loading) return <div className="py-20 text-center">Loading...</div>;

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Notification History</h1>

      {notifications.length === 0 ? (
        <div className="bg-white rounded-xl p-16 text-center text-gray-500">
          No notifications yet.
        </div>
      ) : (
        <div className="space-y-3">
          {notifications.map((notif) => (
            <div
              key={notif.id}
              className={`p-4 rounded-xl border ${
                notif.read ? "bg-white" : "bg-blue-50 border-blue-200"
              }`}
            >
              <p className="font-semibold">{notif.title}</p>
              <p className="text-gray-700 mt-1">{notif.message}</p>
              <p className="text-sm text-gray-500 mt-2">
                {new Date(notif.createdAt).toLocaleString()}
              </p>
              {notif.toolId && (
                <Link
                  href={`/tools/${notif.toolId}`}
                  className="text-indigo-600 text-sm font-medium mt-2 inline-block"
                >
                  View related tool →
                </Link>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
