"use client";

import { useEffect, useState, useCallback } from "react";
import { useSession } from "next-auth/react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import {
  FiPackage,
  FiTruck,
  FiCheckCircle,
  FiXCircle,
  FiClock,
  FiMapPin,
  FiPhone,
} from "react-icons/fi";
import { Suspense } from "react";

const STATUS_LABELS = {
  PENDING_PAYMENT: { label: "Awaiting payment", color: "bg-gray-100 text-gray-700" },
  PAYMENT_SUCCESS: { label: "Payment received", color: "bg-blue-50 text-blue-700" },
  PENDING_VENDOR_ACCEPTANCE: { label: "Awaiting provider approval", color: "bg-amber-50 text-amber-700" },
  ACCEPTED: { label: "Accepted", color: "bg-blue-50 text-blue-700" },
  PREPARING: { label: "Being prepared", color: "bg-blue-50 text-blue-700" },
  READY: { label: "Ready for dispatch", color: "bg-blue-50 text-blue-700" },
  OUT_FOR_DELIVERY: { label: "Out for delivery", color: "bg-indigo-50 text-indigo-700" },
  ACTIVE: { label: "Active", color: "bg-green-50 text-green-700" },
  RETURN_REQUESTED: { label: "Return requested", color: "bg-amber-50 text-amber-700" },
  RETURNED: { label: "Returned", color: "bg-amber-50 text-amber-700" },
  INSPECTION: { label: "Under inspection", color: "bg-amber-50 text-amber-700" },
  COMPLETED: { label: "Completed", color: "bg-green-50 text-green-700" },
  CANCELLED: { label: "Cancelled", color: "bg-red-50 text-red-700" },
};

function money(n) {
  return `₹${Number(n || 0).toLocaleString("en-IN")}`;
}

export default function RentalsPage() {
  return (
    <Suspense fallback={<div className="p-8 text-gray-500">Loading…</div>}>
      <RentalsPageInner />
    </Suspense>
  );
}

function RentalsPageInner() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const searchParams = useSearchParams();

  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState("customer"); // "customer" | "provider"
  const [busyId, setBusyId] = useState(null);
  const [otpInputs, setOtpInputs] = useState({});

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/rentals");
      if (res.ok) setRentals(await res.json());
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (status === "loading") return;
    if (!session) {
      router.push("/login");
      return;
    }
    load();
  }, [session, status, router, load]);

  useEffect(() => {
    if (searchParams.get("success") === "true") {
      // Give the Stripe webhook a moment to land, then refresh.
      const t = setTimeout(load, 1500);
      return () => clearTimeout(t);
    }
  }, [searchParams, load]);

  const userId = session?.user?.id;
  const customerRentals = rentals.filter((r) => r.renterId === userId);
  const providerRentals = rentals.filter((r) => r.tool?.owner?.id === userId);
  const visible = view === "customer" ? customerRentals : providerRentals;

  async function payNow(rentalId) {
    setBusyId(rentalId);
    try {
      const res = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rentalId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not start payment");
      window.location.href = data.url;
    } catch (e) {
      alert(e.message);
      setBusyId(null);
    }
  }

  async function cancelBooking(rental) {
    if (!confirm("Cancel this booking?")) return;
    setBusyId(rental.id);
    try {
      if (rental.status === "PENDING_PAYMENT") {
        const res = await fetch(`/api/rentals/${rental.id}`, { method: "DELETE" });
        if (!res.ok && res.status !== 204) {
          const data = await res.json().catch(() => ({}));
          throw new Error(data.error || "Could not cancel");
        }
      } else {
        await transition(rental.id, "CANCELLED", { reason: "Cancelled by customer" });
      }
      await load();
    } catch (e) {
      alert(e.message);
    } finally {
      setBusyId(null);
    }
  }

  async function transition(rentalId, newStatus, extra = {}) {
    const res = await fetch(`/api/rentals/${rentalId}/status`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ newStatus, ...extra }),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || "Action failed");
    return data;
  }

  async function doTransition(rentalId, newStatus, extra) {
    setBusyId(rentalId);
    try {
      await transition(rentalId, newStatus, extra);
      await load();
    } catch (e) {
      alert(e.message);
    } finally {
      setBusyId(null);
    }
  }

  async function approve(rentalId) {
    setBusyId(rentalId);
    try {
      const res = await fetch(`/api/rentals/${rentalId}/accept`, { method: "POST" });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Could not accept");
      await load();
    } catch (e) {
      alert(e.message);
    } finally {
      setBusyId(null);
    }
  }

  async function reject(rentalId) {
    const reason = window.prompt("Reason for declining (optional):") || "";
    setBusyId(rentalId);
    try {
      const res = await fetch(`/api/rentals/${rentalId}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ reason }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.error || "Could not decline");
      await load();
    } catch (e) {
      alert(e.message);
    } finally {
      setBusyId(null);
    }
  }

  if (status === "loading" || loading) {
    return <div className="p-8 text-gray-500">Loading…</div>;
  }

  return (
    <div className="max-w-3xl mx-auto p-4 lg:p-8">
      <h1 className="text-2xl font-bold mb-1">Bookings</h1>
      <p className="text-gray-500 mb-6">Track everything you're renting/buying and everything booked from you.</p>

      <div className="flex gap-2 mb-6 border-b border-gray-200">
        <button
          onClick={() => setView("customer")}
          className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px ${
            view === "customer" ? "border-indigo-600 text-indigo-700" : "border-transparent text-gray-500"
          }`}
        >
          As Customer ({customerRentals.length})
        </button>
        <button
          onClick={() => setView("provider")}
          className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px ${
            view === "provider" ? "border-indigo-600 text-indigo-700" : "border-transparent text-gray-500"
          }`}
        >
          As Provider ({providerRentals.length})
        </button>
      </div>

      {visible.length === 0 ? (
        <p className="text-gray-400 py-16 text-center">Nothing here yet.</p>
      ) : (
        <div className="space-y-4">
          {visible.map((rental) => (
            <RentalCard
              key={rental.id}
              rental={rental}
              perspective={view}
              busy={busyId === rental.id}
              otp={otpInputs[rental.id] || ""}
              onOtpChange={(v) => setOtpInputs((p) => ({ ...p, [rental.id]: v }))}
              onPay={() => payNow(rental.id)}
              onCancel={() => cancelBooking(rental)}
              onApprove={() => approve(rental.id)}
              onReject={() => reject(rental.id)}
              onTransition={(newStatus, extra) => doTransition(rental.id, newStatus, extra)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function RentalCard({ rental, perspective, busy, otp, onOtpChange, onPay, onCancel, onApprove, onReject, onTransition }) {
  const statusMeta = STATUS_LABELS[rental.status] || { label: rental.status, color: "bg-gray-100 text-gray-700" };
  const isBuy = rental.transactionType === "BUY";
  const counterpart = perspective === "customer" ? rental.tool?.owner : rental.renter;

  return (
    <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
      <div className="p-4 flex gap-4">
        <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
          {rental.tool?.image ? (
            <img src={rental.tool.image} alt={rental.tool.name} className="w-full h-full object-cover" />
          ) : (
            <div className="w-full h-full flex items-center justify-center text-gray-300">
              <FiPackage className="w-8 h-8" />
            </div>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <Link href={`/tools/${rental.toolId}`} className="font-semibold hover:text-indigo-600 truncate">
              {rental.tool?.name}
            </Link>
            <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600 font-medium">
              {isBuy ? "Purchase" : "Rental"}
            </span>
            <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusMeta.color}`}>
              {statusMeta.label}
            </span>
          </div>

          {!isBuy && (
            <p className="text-sm text-gray-500 mt-1">
              {new Date(rental.startDate).toLocaleDateString()} – {new Date(rental.endDate).toLocaleDateString()}
            </p>
          )}
          <p className="text-sm text-gray-500">
            {perspective === "customer" ? "Provider" : "Customer"}: {counterpart?.name || "—"}
          </p>
          <p className="font-semibold mt-1">{money(rental.totalAmount)}</p>

          {rental.status === "CANCELLED" && rental.cancelReason && (
            <p className="text-xs text-red-600 mt-1">Reason: {rental.cancelReason}</p>
          )}
          {rental.paymentStatus === "REFUNDED" && (
            <p className="text-xs text-green-700 mt-1">Refunded {money(rental.refundAmount)}</p>
          )}
        </div>
      </div>

      {/* Handover OTP, shown to the customer once paid */}
      {perspective === "customer" && rental.otpCode && !["COMPLETED", "CANCELLED"].includes(rental.status) && (
        <div className="mx-4 mb-3 px-3 py-2 bg-indigo-50 rounded-lg text-sm text-indigo-800">
          Handover code: <span className="font-mono font-bold tracking-wider">{rental.otpCode}</span>
          <span className="text-indigo-500"> — share this with the provider/courier to confirm receipt.</span>
        </div>
      )}

      {/* Delivery tracking */}
      {rental.delivery && (
        <div className="mx-4 mb-3 px-3 py-2 bg-gray-50 rounded-lg text-sm">
          <p className="font-medium flex items-center gap-1.5">
            <FiTruck className="w-4 h-4" /> {rental.delivery.partnerName} — {rental.delivery.status.replace(/_/g, " ")}
          </p>
          <p className="text-gray-500 text-xs mt-0.5">Tracking: {rental.delivery.trackingNumber}</p>
          {rental.delivery.driverName && (
            <p className="text-gray-500 text-xs flex items-center gap-1">
              <FiPhone className="w-3 h-3" /> {rental.delivery.driverName} · {rental.delivery.driverPhone}
            </p>
          )}
          {rental.delivery.estimatedDeliveryAt && rental.delivery.status !== "DELIVERED" && (
            <p className="text-gray-500 text-xs flex items-center gap-1">
              <FiClock className="w-3 h-3" /> ETA {new Date(rental.delivery.estimatedDeliveryAt).toLocaleString()}
            </p>
          )}
        </div>
      )}

      {rental.pickupType === "DELIVERY" && rental.deliveryAddress && (
        <div className="mx-4 mb-3 flex items-start gap-1.5 text-xs text-gray-500">
          <FiMapPin className="w-3.5 h-3.5 mt-0.5 flex-shrink-0" /> {rental.deliveryAddress}
        </div>
      )}

      {rental.depositRefundStatus === "REFUNDED" && (
        <p className="mx-4 mb-3 text-xs text-green-700">Security deposit refunded.</p>
      )}
      {rental.depositRefundStatus === "FORFEITED" && (
        <p className="mx-4 mb-3 text-xs text-red-600">Security deposit withheld: {rental.depositForfeitReason}</p>
      )}
      {rental.depositRefundStatus === "PENDING" && (
        <p className="mx-4 mb-3 text-xs text-amber-700">Security deposit refund is being processed.</p>
      )}

      {/* Actions */}
      <div className="px-4 py-3 bg-gray-50 border-t border-gray-100 flex flex-wrap gap-2 items-center">
        {["SUCCESS", "REFUNDED", "PARTIALLY_REFUNDED"].includes(rental.paymentStatus) && (
          <a href={`/api/rentals/${rental.id}/invoice`} target="_blank" rel="noreferrer"
            className="px-3 py-1.5 rounded-lg text-sm font-medium bg-white border border-gray-300 text-gray-700 hover:bg-gray-100">
            Invoice
          </a>
        )}
        {perspective === "customer" && (
          <CustomerActions
            rental={rental}
            busy={busy}
            otp={otp}
            onOtpChange={onOtpChange}
            onPay={onPay}
            onCancel={onCancel}
            onTransition={onTransition}
          />
        )}
        {perspective === "provider" && (
          <ProviderActions
            rental={rental}
            busy={busy}
            otp={otp}
            onOtpChange={onOtpChange}
            onApprove={onApprove}
            onReject={onReject}
            onTransition={onTransition}
          />
        )}
      </div>
    </div>
  );
}

async function extendRental(rental) {
  const current = new Date(rental.endDate).toISOString().split("T")[0];
  const input = window.prompt(`Current end date is ${current}. Enter the new end date (YYYY-MM-DD):`);
  if (!input) return;
  const res = await fetch(`/api/rentals/${rental.id}/extend`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ newEndDate: input }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) return alert(data.error || "Could not extend");
  if (confirm(`Extending by ${data.extraDays} day(s) costs Rs ${data.extraTotal}. Continue to payment?`)) {
    window.location.href = data.url;
  }
}

function Btn({ children, onClick, busy, variant = "primary" }) {
  const styles = {
    primary: "bg-indigo-600 text-white hover:bg-indigo-700",
    danger: "bg-red-50 text-red-700 hover:bg-red-100",
    ghost: "bg-white border border-gray-300 text-gray-700 hover:bg-gray-100",
  };
  return (
    <button
      onClick={onClick}
      disabled={busy}
      className={`px-3 py-1.5 rounded-lg text-sm font-medium disabled:opacity-50 ${styles[variant]}`}
    >
      {children}
    </button>
  );
}

function CustomerActions({ rental, busy, otp, onOtpChange, onPay, onCancel, onTransition }) {
  const { status: s, transactionType } = rental;

  if (s === "PENDING_PAYMENT") {
    return (
      <>
        <Btn onClick={onPay} busy={busy}>Pay now</Btn>
        <Btn onClick={onCancel} busy={busy} variant="ghost">Cancel</Btn>
      </>
    );
  }

  if (["PENDING_VENDOR_ACCEPTANCE", "ACCEPTED", "PREPARING", "READY", "OUT_FOR_DELIVERY"].includes(s)) {
    return <Btn onClick={onCancel} busy={busy} variant="ghost">Cancel booking</Btn>;
  }

  if (s === "ACTIVE" && transactionType === "RENT") {
    return (
      <>
        <Btn onClick={() => extendRental(rental)} busy={busy}>Extend rental</Btn>
        <Btn onClick={() => onTransition("RETURN_REQUESTED")} busy={busy} variant="ghost">Request return</Btn>
      </>
    );
  }

  if (s === "COMPLETED") {
    return <span className="text-sm text-gray-400 flex items-center gap-1"><FiCheckCircle className="w-4 h-4" /> Completed</span>;
  }
  if (s === "CANCELLED") {
    return <span className="text-sm text-gray-400 flex items-center gap-1"><FiXCircle className="w-4 h-4" /> Cancelled</span>;
  }

  return null;
}

function ProviderActions({ rental, busy, otp, onOtpChange, onApprove, onReject, onTransition }) {
  const { status: s, transactionType } = rental;

  if (s === "PENDING_VENDOR_ACCEPTANCE") {
    return (
      <>
        <Btn onClick={onApprove} busy={busy}>Approve</Btn>
        <Btn onClick={onReject} busy={busy} variant="danger">Decline</Btn>
      </>
    );
  }
  if (s === "ACCEPTED") {
    return <Btn onClick={() => onTransition("PREPARING")} busy={busy}>Mark preparing</Btn>;
  }
  if (s === "PREPARING") {
    return <Btn onClick={() => onTransition("READY")} busy={busy}>Mark ready</Btn>;
  }
  if (s === "READY") {
    return (
      <Btn onClick={() => onTransition("OUT_FOR_DELIVERY")} busy={busy}>
        {rental.pickupType === "DELIVERY" ? "Dispatch with courier" : "Mark handed to customer for pickup"}
      </Btn>
    );
  }
  if (s === "OUT_FOR_DELIVERY") {
    return (
      <OtpAction
        label="Confirm customer received it"
        otp={otp}
        onOtpChange={onOtpChange}
        onConfirm={() => onTransition("ACTIVE", { otp })}
        busy={busy}
      />
    );
  }
  if (s === "ACTIVE" && transactionType === "BUY") {
    return <Btn onClick={() => onTransition("COMPLETED")} busy={busy}>Mark sale completed</Btn>;
  }
  if (s === "RETURN_REQUESTED") {
    return (
      <OtpAction
        label="Confirm item returned"
        otp={otp}
        onOtpChange={onOtpChange}
        onConfirm={() => onTransition("RETURNED", { otp })}
        busy={busy}
      />
    );
  }
  if (s === "RETURNED") {
    return <Btn onClick={() => onTransition("INSPECTION")} busy={busy}>Start inspection</Btn>;
  }
  if (s === "INSPECTION") {
    return (
      <>
        <Btn onClick={() => onTransition("COMPLETED")} busy={busy}>
          {rental.securityDeposit > 0 ? "Complete and refund deposit" : "Complete — all good"}
        </Btn>
        {rental.securityDeposit > 0 && (
          <Btn
            variant="danger"
            busy={busy}
            onClick={() => {
              const why = window.prompt("Why is the deposit being withheld? (shown to the customer)");
              if (why) onTransition("COMPLETED", { depositDecision: "FORFEIT", depositForfeitReason: why });
            }}
          >
            Complete and withhold deposit
          </Btn>
        )}
      </>
    );
  }
  if (s === "COMPLETED") {
    return <span className="text-sm text-gray-400 flex items-center gap-1"><FiCheckCircle className="w-4 h-4" /> Completed</span>;
  }
  if (s === "CANCELLED") {
    return <span className="text-sm text-gray-400 flex items-center gap-1"><FiXCircle className="w-4 h-4" /> Cancelled</span>;
  }
  return null;
}

function OtpAction({ label, otp, onOtpChange, onConfirm, busy }) {
  return (
    <div className="flex items-center gap-2">
      <input
        value={otp}
        onChange={(e) => onOtpChange(e.target.value)}
        placeholder="Enter 4-digit OTP"
        maxLength={4}
        className="w-28 px-2 py-1.5 border border-gray-300 rounded-lg text-sm font-mono"
      />
      <Btn onClick={onConfirm} busy={busy || otp.length !== 4}>{label}</Btn>
    </div>
  );
}
