"use client";

import Link from "next/link";
import { EVENT_OCCASIONS } from "@/lib/categories";

const occasionEmoji = (name) => {
  const map = {
    "Birthday Celebration": "🎂",
    "Wedding Decoration": "💍",
    "Engagement Decoration": "💍",
    "Anniversary Decoration": "🎉",
    "Baby Shower": "👶",
    "Bridal Shower": "👰",
    "Ganesh Chaturthi Decoration": "🪔",
    "Diwali Decoration": "🪔",
    "Navratri Decoration": "🕺",
    "Holi Decoration": "🌈",
    "Christmas Decoration": "🎄",
    "New Year Decoration": "🎆",
    "Housewarming / Griha Pravesh": "🏠",
    "Puja & Religious Events": "🙏",
    "Corporate Events": "🏢",
    "Other Events": "🎭",
  };
  return map[name] || "🎉";
};

export default function EventsPage() {
  return (
    <div>
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 p-8 md:p-12 mb-8">
        <h1 className="text-4xl md:text-5xl font-extrabold text-white">
          Events & Occasion Decoration
        </h1>
        <p className="text-white/80 mt-3 text-lg max-w-2xl">
          Rent or buy decoration items for birthdays, weddings, festivals, housewarming, and more.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {EVENT_OCCASIONS.map((occasion) => (
          <Link
            key={occasion}
            href={`/tools?group=EVENTS&occasion=${encodeURIComponent(occasion)}`}
            className="bg-white rounded-2xl shadow-sm hover:shadow-md transition p-6 border border-gray-100"
          >
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-indigo-50 flex items-center justify-center text-3xl">
                {occasionEmoji(occasion)}
              </div>
              <div>
                <h3 className="font-bold text-lg text-gray-900">{occasion}</h3>
                <p className="text-sm text-gray-500 mt-1">
                  Browse items for {occasion.toLowerCase()} →
                </p>
              </div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
