"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { FiCheck, FiX, FiClock, FiShield } from "react-icons/fi";

const TABS = [
  { key: "PENDING", label: "Pending" },
  { key: "APPROVED", label: "Approved" },
  { key: "REJECTED", label: "Rejected" },
  { key: "SUSPENDED", label: "Suspended" },
];

export default function AdminProvidersPage() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [tab, setTab] = useState("PENDING");
  const [providers, setProviders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (status === "loading") return;
    if (!session) {
      router.push("/login");
      return;
    }
    if (session.user.role !== "ADMIN") {
      router.push("/tools");
      return;
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [session, status, tab]);

  async function load() {
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/admin/providers?status=${tab}`);
      if (!res.ok) throw new Error("Failed to load providers");
      setProviders(await res.json());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  async function review(id, newStatus) {
    let note = "";
    if (newStatus === "REJECTED" || newStatus === "SUSPENDED") {
      note = window.prompt(`Optional note to include for the ${newStatus === "REJECTED" ? "rejection" : "suspension"}:`) || "";
    }
    setBusyId(id);
    try {
      const res = await fetch(`/api/admin/providers/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: newStatus, note }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Action failed");
      }
      setProviders((prev) => prev.filter((p) => p.id !== id));
    } catch (e) {
      alert(e.message);
    } finally {
      setBusyId(null);
    }
  }

  if (status === "loading" || loading) {
    return <div className="p-8 text-gray-500">Loading…</div>;
  }

  return (
    <div className="max-w-4xl mx-auto p-4 lg:p-8">
      <div className="flex items-center gap-2 mb-1">
        <FiShield className="w-6 h-6 text-indigo-600" />
        <h1 className="text-2xl font-bold">Provider Approvals</h1>
      </div>
      <p className="text-gray-500 mb-6">
        Review applications from equipment owners who want to become Authorised Providers.
      </p>

      <div className="flex gap-2 mb-6 border-b border-gray-200">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={`px-4 py-2 text-sm font-medium border-b-2 -mb-px transition ${
              tab === t.key
                ? "border-indigo-600 text-indigo-700"
                : "border-transparent text-gray-500 hover:text-gray-700"
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {error && <p className="text-red-600 mb-4">{error}</p>}

      {providers.length === 0 ? (
        <p className="text-gray-400 py-12 text-center">No {tab.toLowerCase()} applications.</p>
      ) : (
        <div className="space-y-4">
          {providers.map((p) => (
            <div key={p.id} className="bg-white border border-gray-200 rounded-xl p-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="font-semibold text-lg">{p.businessName || p.name}</p>
                  <p className="text-sm text-gray-500">{p.name} · {p.email}</p>
                  {p.phone && <p className="text-sm text-gray-500">{p.phone}</p>}
                  {p.location && <p className="text-sm text-gray-500">{p.location}</p>}
                  {p.gstNumber && <p className="text-sm text-gray-500">GST: {p.gstNumber}</p>}
                  <p className="text-xs text-gray-400 mt-1 flex items-center gap-1">
                    <FiClock className="w-3 h-3" />
                    Applied {p.providerAppliedAt ? new Date(p.providerAppliedAt).toLocaleString() : "—"}
                  </p>
                  {p._count?.tools > 0 && (
                    <p className="text-xs text-gray-400">{p._count.tools} listing(s) on the platform</p>
                  )}
                  {p.providerNote && (
                    <p className="text-xs text-gray-500 mt-1 italic">Note: {p.providerNote}</p>
                  )}
                </div>

                <div className="flex gap-2 flex-shrink-0">
                  {tab === "PENDING" && (
                    <>
                      <button
                        disabled={busyId === p.id}
                        onClick={() => review(p.id, "APPROVED")}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-green-600 text-white text-sm font-medium hover:bg-green-700 disabled:opacity-50"
                      >
                        <FiCheck className="w-4 h-4" /> Approve
                      </button>
                      <button
                        disabled={busyId === p.id}
                        onClick={() => review(p.id, "REJECTED")}
                        className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-red-50 text-red-700 text-sm font-medium hover:bg-red-100 disabled:opacity-50"
                      >
                        <FiX className="w-4 h-4" /> Reject
                      </button>
                    </>
                  )}
                  {tab === "APPROVED" && (
                    <button
                      disabled={busyId === p.id}
                      onClick={() => review(p.id, "SUSPENDED")}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-amber-50 text-amber-700 text-sm font-medium hover:bg-amber-100 disabled:opacity-50"
                    >
                      Suspend
                    </button>
                  )}
                  {(tab === "REJECTED" || tab === "SUSPENDED") && (
                    <button
                      disabled={busyId === p.id}
                      onClick={() => review(p.id, "APPROVED")}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-green-600 text-white text-sm font-medium hover:bg-green-700 disabled:opacity-50"
                    >
                      <FiCheck className="w-4 h-4" /> Approve
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
