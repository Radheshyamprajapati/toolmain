"use client";

import DecorSetFields, { linesToArray } from "@/components/DecorSetFields";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { CATEGORY_GROUPS, categoriesForGroup, EVENT_OCCASIONS } from "@/lib/categories";

export default function NewToolPage() {
  const router = useRouter();
  const { data: session } = useSession();
  const providerStatus = session?.user?.providerStatus;
  const isBlockedProvider =
    session?.user?.role === "TRADESMAN" && providerStatus && providerStatus !== "APPROVED";
  const isNotAProvider = session && session.user.role !== "TRADESMAN";

  const [form, setForm] = useState({
    name: "",
    description: "",
    categoryGroup: "TOOLS",
    category: "",
    eventOccasion: "",
    pricePerDay: "",
    salePrice: "",
    securityDeposit: "",
    location: "",
    latitude: "",
    longitude: "",
    condition: "Good",
    image: "",

    // ✅ Decor Set fields (EVENTS only)
    setSize: "",
    includedItemsText: "",
    requiredItemsText: "",
    setupInstructions: "",
  });

  const [saving, setSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const allowedCategories = useMemo(() => {
    return categoriesForGroup(form.categoryGroup);
  }, [form.categoryGroup]);

  function updateField(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setSaving(true);
    setErrorMessage("");

    try {
      const isEvents = form.categoryGroup === "EVENTS";

      const payload = {
        name: form.name,
        description: form.description,
        categoryGroup: form.categoryGroup,
        category: form.category,
        eventOccasion: isEvents ? form.eventOccasion : null,

        pricePerDay: Number(form.pricePerDay),
        salePrice: form.salePrice ? Number(form.salePrice) : null,
        securityDeposit: form.securityDeposit ? Number(form.securityDeposit) : 0,

        image: form.image || null,
        location: form.location,
        latitude: form.latitude ? Number(form.latitude) : null,
        longitude: form.longitude ? Number(form.longitude) : null,
        condition: form.condition,
        isAvailable: true,

        // ✅ Decor set payload (only for EVENTS)
        setSize: isEvents ? (form.setSize || null) : null,
        includedItems: isEvents ? linesToArray(form.includedItemsText) : null,
        requiredItems: isEvents ? linesToArray(form.requiredItemsText) : null,
        setupInstructions: isEvents ? (form.setupInstructions || null) : null,
      };

      const res = await fetch("/api/tools", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || `Request failed: ${res.status}`);
      }

      router.push("/tools");
      router.refresh();
    } catch (err) {
      console.error(err);
      setErrorMessage(err.message || "Failed to create tool");
      setSaving(false);
    }
  }

  const input =
    "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none";
  const label = "block text-sm font-medium text-gray-700 mb-1";

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold">Add a New Listing</h1>
        <Link href="/tools" className="text-indigo-600 hover:text-indigo-500 font-medium">
          ← Back to Tools
        </Link>
      </div>

      {errorMessage && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg mb-6">
          <strong>Error:</strong> {errorMessage}
        </div>
      )}

      {isNotAProvider && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-lg mb-6">
          Only registered equipment providers can list tools. Register as a provider from your
          profile, or <Link href="/register" className="underline font-medium">apply here</Link>.
        </div>
      )}
      {isBlockedProvider && providerStatus === "PENDING" && (
        <div className="bg-amber-50 border border-amber-200 text-amber-800 p-4 rounded-lg mb-6">
          Your provider application is still under review. You'll be able to list tools once an
          admin approves it.
        </div>
      )}
      {isBlockedProvider && providerStatus !== "PENDING" && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg mb-6">
          Your provider account isn't currently approved to list tools. Contact support for details.
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm p-6 max-w-3xl">
        <fieldset disabled={isBlockedProvider || isNotAProvider} className="contents">
        <div className="space-y-4">
          <div>
            <label className={label}>Name *</label>
            <input
              className={input}
              value={form.name}
              onChange={(e) => updateField("name", e.target.value)}
              required
            />
          </div>

          <div>
            <label className={label}>Description *</label>
            <textarea
              className={input}
              rows={3}
              value={form.description}
              onChange={(e) => updateField("description", e.target.value)}
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={label}>Category Group *</label>
              <select
                className={input}
                value={form.categoryGroup}
                onChange={(e) => {
                  const group = e.target.value;
                  updateField("categoryGroup", group);
                  updateField("category", "");
                  updateField("eventOccasion", "");

                  // ✅ reset decor fields when group changes
                  updateField("setSize", "");
                  updateField("includedItemsText", "");
                  updateField("requiredItemsText", "");
                  updateField("setupInstructions", "");
                }}
              >
                {CATEGORY_GROUPS.map((g) => (
                  <option key={g.key} value={g.key}>
                    {g.shortLabel}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className={label}>Category / Item Type *</label>
              <select
                className={input}
                value={form.category}
                onChange={(e) => updateField("category", e.target.value)}
                required
              >
                <option value="" disabled>
                  Select a category
                </option>
                {allowedCategories.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {form.categoryGroup === "EVENTS" && (
            <div>
              <label className={label}>Event Occasion *</label>
              <select
                className={input}
                value={form.eventOccasion}
                onChange={(e) => updateField("eventOccasion", e.target.value)}
                required
              >
                <option value="" disabled>
                  Select occasion
                </option>
                {EVENT_OCCASIONS.map((o) => (
                  <option key={o} value={o}>
                    {o}
                  </option>
                ))}
              </select>
            </div>
          )}

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className={label}>Rent Price / Day *</label>
              <input
                className={input}
                type="number"
                min="0"
                step="0.01"
                value={form.pricePerDay}
                onChange={(e) => updateField("pricePerDay", e.target.value)}
                required
              />
            </div>
            <div>
              <label className={label}>Sale Price (optional)</label>
              <input
                className={input}
                type="number"
                min="0"
                step="0.01"
                value={form.salePrice}
                onChange={(e) => updateField("salePrice", e.target.value)}
              />
            </div>
            <div>
              <label className={label}>Security Deposit (optional)</label>
              <input
                className={input}
                type="number"
                min="0"
                step="0.01"
                value={form.securityDeposit}
                onChange={(e) => updateField("securityDeposit", e.target.value)}
              />
            </div>
          </div>

          {/* ✅ Decor Set Details (EVENTS only) */}
          {form.categoryGroup === "EVENTS" && (
            <DecorSetFields
              form={form}
              setForm={setForm}
              labelClasses={label}
              inputClasses={input}
            />
          )}

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={label}>Location *</label>
              <input
                className={input}
                value={form.location}
                onChange={(e) => updateField("location", e.target.value)}
                required
              />
            </div>
            <div>
              <label className={label}>Condition *</label>
              <select
                className={input}
                value={form.condition}
                onChange={(e) => updateField("condition", e.target.value)}
              >
                <option>Excellent</option>
                <option>Good</option>
                <option>Fair</option>
                <option>New</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className={label}>Latitude (optional)</label>
              <input
                className={input}
                type="number"
                step="any"
                value={form.latitude}
                onChange={(e) => updateField("latitude", e.target.value)}
              />
            </div>
            <div>
              <label className={label}>Longitude (optional)</label>
              <input
                className={input}
                type="number"
                step="any"
                value={form.longitude}
                onChange={(e) => updateField("longitude", e.target.value)}
              />
            </div>
          </div>

          {/* Camera / Upload */}
          <div>
            <label className={label}>Image (optional)</label>
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onload = (ev) => updateField("image", ev.target.result);
                  reader.readAsDataURL(file);
                }
              }}
              className="mt-1 block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-medium file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
            />
            {form.image && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={form.image}
                alt="Preview"
                className="mt-2 h-32 w-32 object-cover rounded-lg"
              />
            )}
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              disabled={saving || isBlockedProvider || isNotAProvider}
              className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-medium hover:bg-indigo-700 transition disabled:opacity-50"
            >
              {saving ? "Saving..." : "Create Listing"}
            </button>
            <Link
              href="/tools"
              className="bg-gray-100 text-gray-700 px-6 py-2 rounded-lg font-medium hover:bg-gray-200 transition"
            >
              Cancel
            </Link>
          </div>
        </div>
        </fieldset>
      </form>
    </div>
  );
}
