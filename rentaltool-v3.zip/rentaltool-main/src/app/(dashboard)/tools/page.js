"use client";

import { useEffect, useMemo, useState } from "react";
import ToolCard from "@/components/ToolCard";
import SkeletonCard from "@/components/SkeletonCard";
import EmptyState from "@/components/EmptyState";
import Link from "next/link";
import { FiPlus, FiSearch, FiFilter } from "react-icons/fi";
import { CATEGORY_GROUPS } from "@/lib/categories";

export default function ToolsPage() {
  const [tools, setTools] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [userLoc, setUserLoc] = useState(null);
  const [sortByDistance, setSortByDistance] = useState(false);
  const [activeGroup, setActiveGroup] = useState("ALL");

  // Get user location (optional)
  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setUserLoc({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => {}
    );
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError("");

      try {
        const url = activeGroup === "ALL" ? "/api/tools" : `/api/tools?group=${activeGroup}`;
        const res = await fetch(url);

        if (!res.ok) {
          const text = await res.text();
          throw new Error(`API ${res.status}: ${text || res.statusText}`);
        }

        const data = await res.json();
        if (!cancelled) setTools(Array.isArray(data) ? data : []);
      } catch (e) {
        console.error("Load tools failed:", e);
        if (!cancelled) {
          setTools([]);
          setError(e.message || "Failed to load tools");
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    }

    load();
    return () => {
      cancelled = true;
    };
  }, [activeGroup]);

  function haversine(lat1, lon1, lat2, lon2) {
    if (lat1 == null || lon1 == null || lat2 == null || lon2 == null) return 999999;
    const R = 6371;
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLon / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(a));
  }

  const filteredTools = useMemo(() => {
    const q = search.toLowerCase();
    const base = tools.filter((tool) => {
      const name = (tool?.name || "").toLowerCase();
      const cat = (tool?.category || "").toLowerCase();
      return name.includes(q) || cat.includes(q);
    });

    if (userLoc && sortByDistance) {
      return [...base].sort((a, b) => {
        const dA = haversine(userLoc.lat, userLoc.lng, a.latitude, a.longitude);
        const dB = haversine(userLoc.lat, userLoc.lng, b.latitude, b.longitude);
        return dA - dB;
      });
    }

    return base;
  }, [tools, search, userLoc, sortByDistance]);

  return (
    <div>
      {/* Hero */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 p-8 md:p-12 mb-8">
        <div className="relative z-10">
          <h1 className="text-4xl md:text-5xl font-extrabold text-white">Your Perfect Tool & Decor Item</h1>
          <p className="text-white/80 mt-3 text-lg max-w-2xl">
            Rent from trusted electricians and builders near you. Or buy equipment instantly.
          </p>

          <div className="mt-6 flex flex-col sm:flex-row gap-3 max-w-xl">
            <div className="flex-1 flex items-center bg-white rounded-full px-4 py-2">
              <FiSearch className="text-gray-400" />
              <input
                type="text"
                placeholder="Search tools..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="flex-1 ml-2 outline-none bg-transparent"
              />
            </div>

            <button
              onClick={() => setSortByDistance(!sortByDistance)}
              className="flex items-center gap-2 bg-white/20 backdrop-blur text-white px-5 py-2 rounded-full font-medium hover:bg-white/30 transition"
            >
              <FiFilter /> {sortByDistance ? "Nearest First" : "Sort by Distance"}
            </button>
          </div>
        </div>

        <div className="absolute right-0 top-0 bottom-0 w-1/3 bg-white/10 backdrop-blur skew-x-12 hidden md:block" />
      </div>

      {/* Group tabs */}
      <div className="flex flex-wrap gap-3 mb-6">
        <button
          onClick={() => setActiveGroup("ALL")}
          className={`flex items-center gap-2 px-4 py-2 rounded-full font-medium transition ${
            activeGroup === "ALL" ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
          }`}
        >
          📦 All Listings
        </button>
        {CATEGORY_GROUPS.map((group) => (
          <button
            key={group.key}
            onClick={() => setActiveGroup(group.key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full font-medium transition ${
              activeGroup === group.key ? "bg-gray-900 text-white" : "bg-gray-100 text-gray-600 hover:bg-gray-200"
            }`}
          >
            {group.icon} {group.shortLabel}
          </button>
        ))}
      </div>

      {/* Add tool */}
      <div className="flex justify-end mb-6">
        <Link
          href="/tools/new"
          className="bg-indigo-600 text-white px-6 py-3 rounded-full font-semibold shadow-lg hover:bg-indigo-700 transition flex items-center gap-2"
        >
          <FiPlus /> Add Your Tool
        </Link>
      </div>

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-lg mb-6">
          {error}
        </div>
      )}

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : filteredTools.length === 0 ? (
        <EmptyState
          icon={<span className="text-4xl">🔧</span>}
          title="No tools found"
          description="Try a different search or list your own tool."
          action={
            <Link href="/tools/new" className="bg-indigo-600 text-white px-6 py-3 rounded-lg font-medium">
              List a Tool
            </Link>
          }
        />
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTools.map((tool) => {
            const distance =
              userLoc && tool.latitude != null
                ? haversine(userLoc.lat, userLoc.lng, tool.latitude, tool.longitude)
                : undefined;

            return <ToolCard key={tool.id} tool={tool} distance={distance} />;
          })}
        </div>
      )}
    </div>
  );
}
