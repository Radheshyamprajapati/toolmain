"use client";

import { linesToArray } from "@/components/DecorSetFields";
import ImageUploader from "@/components/ImageUploader";
import AvailabilityCalendar from "@/components/AvailabilityCalendar";
import { CATEGORY_GROUPS, categoriesForGroup, EVENT_OCCASIONS } from "@/lib/categories";
import { useEffect, useMemo, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import {
  FiEdit,
  FiTrash,
  FiMapPin,
  FiStar,
  FiArrowLeft,
  FiShoppingCart,
} from "react-icons/fi";

function arrayToLines(arr) {
  return Array.isArray(arr) ? arr.join("\n") : "";
}

export default function ToolDetailPage({ params }) {
  const { data: session } = useSession();
  const router = useRouter();

  const [tool, setTool] = useState(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);

  // Rental / purchase state
  const [mode, setMode] = useState("rent"); // "rent" or "buy"
  const [rentDays, setRentDays] = useState(1);
  const [totalCost, setTotalCost] = useState(0);
  const [startDateStr, setStartDateStr] = useState(() => new Date().toISOString().split("T")[0]);
  const [pickupType, setPickupType] = useState("PICKUP");
  const [deliveryAddress, setDeliveryAddress] = useState("");
  const [submitting, setSubmitting] = useState(false);

  // Edit form state (includes decor fields)
  const [form, setForm] = useState({
    name: "",
    description: "",
    categoryGroup: "TOOLS",
    category: "",
    eventOccasion: "",
    pricePerDay: "",
    salePrice: "",
    securityDeposit: "",
    location: "",
    latitude: "",
    longitude: "",
    condition: "Good",
    image: "",
    isAvailable: true,

    // Decor fields (EVENTS only)
    setSize: "",
    includedItemsText: "",
    requiredItemsText: "",
    setupInstructions: "",
  });

  const allowedCategories = useMemo(() => {
    return categoriesForGroup(form.categoryGroup);
  }, [form.categoryGroup]);

  useEffect(() => {
    async function load() {
      try {
        const res = await fetch(`/api/tools/${params.id}`);
        if (!res.ok) throw new Error("Failed to load tool");
        const data = await res.json();

        setTool(data);
        setTotalCost((data.pricePerDay || 0) * 1);

        setForm({
          name: data.name || "",
          description: data.description || "",
          categoryGroup: data.categoryGroup || "TOOLS",
          category: data.category || "",
          eventOccasion: data.eventOccasion || "",
          pricePerDay: data.pricePerDay ?? "",
          salePrice: data.salePrice ?? "",
          securityDeposit: data.securityDeposit ?? "",
          location: data.location || "",
          latitude: data.latitude ?? "",
          longitude: data.longitude ?? "",
          condition: data.condition || "Good",
          image: data.image || "",
          isAvailable: data.isAvailable ?? true,

          // Decor fields
          setSize: data.setSize || "",
          includedItemsText: arrayToLines(data.includedItems),
          requiredItemsText: arrayToLines(data.requiredItems),
          setupInstructions: data.setupInstructions || "",
        });
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }

    load();
  }, [params.id]);

  if (loading) return <div>Loading...</div>;
  if (!tool) return <div>Tool not found</div>;

  const isOwner = session?.user?.id === tool.ownerId;

  // Update total when days or mode changes
  function updateTotal(days, selectedMode) {
    if (selectedMode === "buy") setTotalCost(tool.salePrice || 0);
    else setTotalCost(days * (tool.pricePerDay || 0));
  }

  function handleModeChange(newMode) {
    setMode(newMode);
    updateTotal(rentDays, newMode);
  }

  function handleDaysChange(e) {
    const days = Math.max(1, parseInt(e.target.value || "1", 10));
    setRentDays(days);
    updateTotal(days, mode);
  }

  // Create rental (rent) or purchase (buy), then hand off to Stripe Checkout
  // (Stripe Checkout itself offers both card and UPI — see create-checkout-session).
  async function handleBookOrBuy() {
    if (!session) {
      router.push("/login");
      return;
    }
    if (mode === "buy" && !(tool.salePrice > 0)) {
      alert("This item isn't listed for purchase.");
      return;
    }
    if (pickupType === "DELIVERY" && !deliveryAddress.trim()) {
      alert("Please enter a delivery address.");
      return;
    }

    setSubmitting(true);
    try {
      const body = {
        toolId: tool.id,
        transactionType: mode === "buy" ? "BUY" : "RENT",
        pickupType,
        deliveryAddress: pickupType === "DELIVERY" ? deliveryAddress.trim() : undefined,
      };

      if (mode === "rent") {
        const start = new Date(startDateStr + "T10:00:00");
        const end = new Date(start);
        end.setDate(start.getDate() + rentDays);
        body.startAt = start.toISOString();
        body.endAt = end.toISOString();
      }

      const rentalRes = await fetch("/api/rentals", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const rentalResp = await rentalRes.json().catch(() => ({}));
      if (!rentalRes.ok) {
        throw new Error(rentalResp.error || "Failed to create booking");
      }

      const rentalId = rentalResp.rentalId;
      if (!rentalId) throw new Error("Booking created but no rentalId was returned.");

      const checkoutRes = await fetch("/api/create-checkout-session", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ rentalId }),
      });
      const checkoutData = await checkoutRes.json().catch(() => ({}));
      if (!checkoutRes.ok || !checkoutData.url) {
        throw new Error(checkoutData.error || "Failed to start payment");
      }

      window.location.href = checkoutData.url;
    } catch (e) {
      alert(e.message || "Something went wrong");
      setSubmitting(false);
    }
  }

  async function handleUpdate(e) {
    e.preventDefault();

    try {
      const isEvents = form.categoryGroup === "EVENTS";

      const payload = {
        name: form.name,
        description: form.description,
        categoryGroup: form.categoryGroup,
        category: form.category,
        eventOccasion: isEvents ? form.eventOccasion : null,
        pricePerDay: Number(form.pricePerDay),
        salePrice: form.salePrice ? Number(form.salePrice) : null,
        securityDeposit: form.securityDeposit ? Number(form.securityDeposit) : 0,
        image: form.image || null,
        location: form.location,
        latitude: form.latitude ? Number(form.latitude) : null,
        longitude: form.longitude ? Number(form.longitude) : null,
        condition: form.condition,
        isAvailable: form.isAvailable,

        // Decor fields
        setSize: isEvents ? (form.setSize || null) : null,
        includedItems: isEvents ? linesToArray(form.includedItemsText) : null,
        requiredItems: isEvents ? linesToArray(form.requiredItemsText) : null,
        setupInstructions: isEvents ? (form.setupInstructions || null) : null,
      };

      const res = await fetch(`/api/tools/${tool.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Failed to update tool");
      }

      const updated = await res.json();
      setTool(updated);
      setEditing(false);
    } catch (e) {
      console.error(e);
      alert(e.message || "Update failed");
    }
  }

  async function handleDelete() {
    if (!confirm("Are you sure you want to delete this listing?")) return;

    const res = await fetch(`/api/tools/${tool.id}`, { method: "DELETE" });
    if (res.ok) router.push("/tools");
    else alert("Failed to delete tool");
  }

  const inputClasses =
    "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none";
  const labelClasses = "block text-sm font-medium text-gray-700 mb-1";

  // ----------------- EDIT MODE -----------------
  if (editing) {
    return (
      <div className="max-w-3xl mx-auto p-4">
        <button
          onClick={() => setEditing(false)}
          className="text-indigo-600 hover:text-indigo-500 font-medium mb-4 inline-flex items-center gap-1"
        >
          <FiArrowLeft /> Back to details
        </button>

        <form onSubmit={handleUpdate} className="bg-white rounded-xl shadow-sm p-6">
          <h2 className="text-2xl font-bold mb-4">Edit Listing</h2>

          <div className="space-y-4">
            {/* Name */}
            <div>
              <label className={labelClasses}>Name *</label>
              <input
                className={inputClasses}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>

            {/* Description */}
            <div>
              <label className={labelClasses}>Description *</label>
              <textarea
                className={inputClasses}
                rows={3}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                required
              />
            </div>

            {/* Category group + category */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className={labelClasses}>Category Group *</label>
                <select
                  className={inputClasses}
                  value={form.categoryGroup}
                  onChange={(e) => {
                    const group = e.target.value;
                    setForm((prev) => ({
                      ...prev,
                      categoryGroup: group,
                      category: "",
                      eventOccasion: "",
                      setSize: "",
                      includedItemsText: "",
                      requiredItemsText: "",
                      setupInstructions: "",
                    }));
                  }}
                >
                  {CATEGORY_GROUPS.map((g) => (
                    <option key={g.key} value={g.key}>
                      {g.shortLabel}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className={labelClasses}>Category *</label>
                <select
                  className={inputClasses}
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  required
                >
                  <option value="">Select category</option>
                  {allowedCategories.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Event occasion (only for EVENTS) */}
            {form.categoryGroup === "EVENTS" && (
              <div>
                <label className={labelClasses}>Event Occasion</label>
                <select
                  className={inputClasses}
                  value={form.eventOccasion}
                  onChange={(e) => setForm({ ...form, eventOccasion: e.target.value })}
                >
                  <option value="">Select occasion</option>
                  {EVENT_OCCASIONS.map((occ) => (
                    <option key={occ} value={occ}>
                      {occ}
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Price fields */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className={labelClasses}>Price per Day *</label>
                <input
                  type="number"
                  className={inputClasses}
                  value={form.pricePerDay}
                  onChange={(e) => setForm({ ...form, pricePerDay: e.target.value })}
                  required
                  min="0"
                />
              </div>
              <div>
                <label className={labelClasses}>Sale Price</label>
                <input
                  type="number"
                  className={inputClasses}
                  value={form.salePrice}
                  onChange={(e) => setForm({ ...form, salePrice: e.target.value })}
                  min="0"
                />
              </div>
              <div>
                <label className={labelClasses}>Security Deposit</label>
                <input
                  type="number"
                  className={inputClasses}
                  value={form.securityDeposit}
                  onChange={(e) => setForm({ ...form, securityDeposit: e.target.value })}
                  min="0"
                />
              </div>
            </div>

            {/* Location */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className={labelClasses}>Location *</label>
                <input
                  className={inputClasses}
                  value={form.location}
                  onChange={(e) => setForm({ ...form, location: e.target.value })}
                  required
                />
              </div>
              <div>
                <label className={labelClasses}>Latitude</label>
                <input
                  type="number"
                  step="any"
                  className={inputClasses}
                  value={form.latitude}
                  onChange={(e) => setForm({ ...form, latitude: e.target.value })}
                />
              </div>
              <div>
                <label className={labelClasses}>Longitude</label>
                <input
                  type="number"
                  step="any"
                  className={inputClasses}
                  value={form.longitude}
                  onChange={(e) => setForm({ ...form, longitude: e.target.value })}
                />
              </div>
            </div>

            {/* Condition */}
            <div>
              <label className={labelClasses}>Condition *</label>
              <select
                className={inputClasses}
                value={form.condition}
                onChange={(e) => setForm({ ...form, condition: e.target.value })}
                required
              >
                <option value="New">New</option>
                <option value="Good">Good</option>
                <option value="Fair">Fair</option>
                <option value="Used">Used</option>
              </select>
            </div>

            <ImageUploader value={form.image} onChange={(url) => setForm({ ...form, image: url })} />

            {/* Decor fields (only for EVENTS) */}
            {form.categoryGroup === "EVENTS" && (
              <div className="space-y-4">
                <div>
                  <label className={labelClasses}>Set Size</label>
                  <input
                    className={inputClasses}
                    value={form.setSize}
                    onChange={(e) => setForm({ ...form, setSize: e.target.value })}
                    placeholder="e.g., 10ft x 8ft, Large"
                  />
                </div>
                <div>
                  <label className={labelClasses}>Included Items (one per line)</label>
                  <textarea
                    className={inputClasses}
                    rows={3}
                    value={form.includedItemsText}
                    onChange={(e) => setForm({ ...form, includedItemsText: e.target.value })}
                    placeholder="Item 1&#10;Item 2"
                  />
                </div>
                <div>
                  <label className={labelClasses}>Required Items (one per line)</label>
                  <textarea
                    className={inputClasses}
                    rows={3}
                    value={form.requiredItemsText}
                    onChange={(e) => setForm({ ...form, requiredItemsText: e.target.value })}
                    placeholder="Item A&#10;Item B"
                  />
                </div>
                <div>
                  <label className={labelClasses}>Setup Instructions</label>
                  <textarea
                    className={inputClasses}
                    rows={3}
                    value={form.setupInstructions}
                    onChange={(e) => setForm({ ...form, setupInstructions: e.target.value })}
                    placeholder="Any special instructions..."
                  />
                </div>
              </div>
            )}

            {/* Availability */}
            <label className="inline-flex items-center gap-2">
              <input
                type="checkbox"
                checked={form.isAvailable}
                onChange={(e) => setForm({ ...form, isAvailable: e.target.checked })}
                className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
              />
              <span className="text-sm font-medium text-gray-700">Available for rent/purchase</span>
            </label>
          </div>

          <div className="mt-6 flex gap-3">
            <button
              type="submit"
              className="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition"
            >
              Save Changes
            </button>
            <button
              type="button"
              onClick={() => setEditing(false)}
              className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 text-gray-700"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    );
  }

  // ----------------- DISPLAY MODE -----------------
  return (
    <div className="max-w-5xl mx-auto p-4">
      {/* Back button */}
      <Link
        href="/tools"
        className="inline-flex items-center gap-1 text-indigo-600 hover:text-indigo-500 font-medium mb-4"
      >
        <FiArrowLeft /> Back to Tools
      </Link>

      {/* Tool details card */}
      <div className="bg-white rounded-xl shadow-sm overflow-hidden">
        <div className="md:flex">
          {/* Image */}
          <div className="md:w-1/2 h-64 md:h-auto">
            {tool.image ? (
              <img
                src={tool.image}
                alt={tool.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400 text-6xl">
                🛠️
              </div>
            )}
          </div>

          {/* Details */}
          <div className="p-6 md:w-1/2">
            <div className="flex justify-between items-start">
              <h1 className="text-2xl font-bold text-gray-900">{tool.name}</h1>
              {isOwner && (
                <div className="flex gap-2">
                  <button
                    onClick={() => setEditing(true)}
                    className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-full"
                    title="Edit"
                  >
                    <FiEdit className="text-xl" />
                  </button>
                  <button
                    onClick={handleDelete}
                    className="p-2 text-red-600 hover:bg-red-50 rounded-full"
                    title="Delete"
                  >
                    <FiTrash className="text-xl" />
                  </button>
                </div>
              )}
            </div>

            <div className="mt-2 flex items-center gap-2 text-sm text-gray-600">
              <FiMapPin className="text-gray-400" />
              {tool.location}
            </div>

            <div className="mt-2 flex items-center gap-1 text-yellow-500">
              <FiStar className="fill-current" />
              <span className="ml-1 text-gray-700 font-medium">{tool.rating?.toFixed(1) || "0.0"}</span>
              <span className="text-gray-400 text-sm">(rating)</span>
            </div>

            {isOwner && (
              <div className="mt-4">
                <AvailabilityCalendar toolId={tool.id} isOwner={true} />
              </div>
            )}

            <div className="mt-4">
              <span className="inline-block bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded">
                {tool.categoryGroup}
              </span>
              <span className="ml-2 inline-block bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded">
                {tool.category}
              </span>
              {tool.eventOccasion && (
                <span className="ml-2 inline-block bg-purple-100 text-purple-800 text-xs font-medium px-2.5 py-0.5 rounded">
                  {tool.eventOccasion}
                </span>
              )}
            </div>

            <p className="mt-4 text-gray-600">{tool.description}</p>

            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Condition:</span>
                <span className="font-medium">{tool.condition}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Price per day:</span>
                <span className="font-semibold">₹{tool.pricePerDay}</span>
              </div>
              {tool.salePrice && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Sale price:</span>
                  <span className="font-semibold">₹{tool.salePrice}</span>
                </div>
              )}
              {tool.securityDeposit > 0 && (
                <div className="flex justify-between">
                  <span className="text-gray-500">Security deposit:</span>
                  <span className="font-semibold">₹{tool.securityDeposit}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-gray-500">Availability:</span>
                <span className={`font-medium ${tool.isAvailable ? "text-green-600" : "text-red-600"}`}>
                  {tool.isAvailable ? "Available" : "Not available"}
                </span>
              </div>
            </div>

            {/* Rental / Buy section */}
            {!isOwner && (
              <div className="mt-6 border-t pt-4">
                <div className="mb-4">
                  <AvailabilityCalendar toolId={tool.id} isOwner={false} />
                </div>
                <div className="flex items-center gap-3 mb-3">
                  <button
                    onClick={() => handleModeChange("rent")}
                    className={`px-4 py-2 rounded-lg font-medium ${
                      mode === "rent"
                        ? "bg-indigo-600 text-white"
                        : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                    }`}
                  >
                    Rent
                  </button>
                  {tool.salePrice > 0 && (
                    <button
                      onClick={() => handleModeChange("buy")}
                      className={`px-4 py-2 rounded-lg font-medium ${
                        mode === "buy"
                          ? "bg-indigo-600 text-white"
                          : "bg-gray-200 text-gray-700 hover:bg-gray-300"
                      }`}
                    >
                      Buy
                    </button>
                  )}
                </div>

                {mode === "rent" && (
                  <div className="grid grid-cols-2 gap-3 mb-3">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Start date
                      </label>
                      <input
                        type="date"
                        min={new Date().toISOString().split("T")[0]}
                        value={startDateStr}
                        onChange={(e) => setStartDateStr(e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Number of days
                      </label>
                      <input
                        type="number"
                        min="1"
                        value={rentDays}
                        onChange={handleDaysChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                      />
                    </div>
                  </div>
                )}

                <div className="mb-3">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Pickup or delivery
                  </label>
                  <div className="flex gap-3">
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="radio"
                        checked={pickupType === "PICKUP"}
                        onChange={() => setPickupType("PICKUP")}
                      />
                      Self pickup
                    </label>
                    <label className="flex items-center gap-2 text-sm">
                      <input
                        type="radio"
                        checked={pickupType === "DELIVERY"}
                        onChange={() => setPickupType("DELIVERY")}
                      />
                      Home delivery (+₹100)
                    </label>
                  </div>
                  {pickupType === "DELIVERY" && (
                    <input
                      value={deliveryAddress}
                      onChange={(e) => setDeliveryAddress(e.target.value)}
                      placeholder="Delivery address"
                      className="mt-2 w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                    />
                  )}
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Estimated cost</p>
                    <p className="text-2xl font-bold text-gray-900">₹{totalCost.toFixed(2)}</p>
                    <p className="text-xs text-gray-400">+ delivery/platform fees shown at checkout</p>
                  </div>
                  <button
                    onClick={handleBookOrBuy}
                    disabled={!tool.isAvailable || submitting}
                    className="inline-flex items-center gap-2 bg-indigo-600 text-white px-6 py-2 rounded-lg hover:bg-indigo-700 transition disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <FiShoppingCart />
                    {submitting ? "Please wait…" : mode === "buy" ? "Buy now" : "Proceed to payment"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
