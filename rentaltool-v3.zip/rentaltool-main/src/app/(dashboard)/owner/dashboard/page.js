"use client";

import { useEffect, useState } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { FiDollarSign, FiClock, FiAlertCircle } from "react-icons/fi";

export default function OwnerDashboard() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const [stats, setStats] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/login");
      return;
    }
    if (session && session.user.role !== "TRADESMAN") {
      router.push("/tools");
    }
  }, [session, status, router]);

  useEffect(() => {
    if (session?.user?.role !== "TRADESMAN") return;
    fetch("/api/owner/stats")
      .then(async (res) => {
        if (!res.ok) throw new Error((await res.json().catch(() => ({}))).error || "Failed to load stats");
        return res.json();
      })
      .then(setStats)
      .catch((e) => setError(e.message));
  }, [session]);

  if (status === "loading" || !session) return <div className="p-8 text-gray-500">Loading…</div>;
  if (session.user.role !== "TRADESMAN") return null;

  const providerStatus = session.user.providerStatus;

  if (providerStatus !== "APPROVED") {
    return (
      <div className="max-w-xl mx-auto mt-12 bg-white rounded-xl shadow-sm p-8 text-center">
        <FiClock className="w-10 h-10 text-amber-500 mx-auto mb-3" />
        <h1 className="text-xl font-bold mb-2">
          {providerStatus === "PENDING" ? "Application under review" : "Provider account not active"}
        </h1>
        <p className="text-gray-500">
          {providerStatus === "PENDING"
            ? "We're reviewing your provider application. You'll be notified as soon as it's approved and you can start listing tools."
            : "Your provider account isn't currently approved to operate on the platform. Please contact support."}
        </p>
      </div>
    );
  }

  if (error) return <div className="p-8 text-red-600">{error}</div>;
  if (!stats) return <div className="p-8 text-gray-500">Loading…</div>;

  const cards = [
    { label: "Today", value: stats.daily },
    { label: "This Week", value: stats.weekly },
    { label: "This Month", value: stats.monthly },
    { label: "All Time", value: stats.total },
  ];

  return (
    <div>
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <h1 className="text-3xl font-bold">Owner Dashboard</h1>
        <Link
          href="/rentals"
          className="inline-flex items-center gap-2 bg-white border border-gray-200 px-4 py-2 rounded-lg text-sm font-medium hover:bg-gray-50"
        >
          <FiAlertCircle className="text-amber-500" />
          {stats.pendingApproval} booking{stats.pendingApproval === 1 ? "" : "s"} awaiting your approval
        </Link>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((card) => (
          <div key={card.label} className="bg-white rounded-xl shadow-sm p-6">
            <div className="flex items-center gap-2 text-gray-500 mb-2">
              <FiDollarSign />
              <span className="text-sm">{card.label}</span>
            </div>
            <p className="text-3xl font-bold">₹{card.value.toFixed(2)}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
