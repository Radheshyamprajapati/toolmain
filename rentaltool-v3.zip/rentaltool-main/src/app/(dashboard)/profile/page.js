"use client";

import { useSession } from "next-auth/react";
import { useState } from "react";
import { FiEdit, FiMail, FiPhone, FiMapPin, FiTool, FiCalendar } from "react-icons/fi";
import LoadingSpinner from "@/components/LoadingSpinner";

export default function ProfilePage() {
  const { data: session, status } = useSession();
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({
    name: session?.user?.name || "",
    email: session?.user?.email || "",
    phone: "",
    location: "",
  });

  if (status === "loading") return <LoadingSpinner />;

  // Dummy stats – replace with real data later
  const stats = {
    toolsListed: session?.user?.role === "TRADESMAN" ? 12 : 0,
    rentals: 25,
    rating: "4.9",
    memberSince: "2024"
  };

  const inputClasses = "w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none";

  return (
    <div>
      {/* Cover Photo */}
      <div className="relative h-48 rounded-3xl overflow-hidden bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 mb-20">
        <div className="absolute inset-0 bg-black/20" />
      </div>

      {/* Profile Card Overlapping */}
      <div className="max-w-4xl mx-auto -mt-20 relative z-10">
        <div className="bg-white rounded-3xl shadow-xl p-6 md:p-8">
          <div className="flex flex-col md:flex-row items-center gap-6">
            {/* Avatar */}
            <div className="w-28 h-28 rounded-3xl bg-indigo-100 flex items-center justify-center text-5xl font-bold text-indigo-600 border-4 border-white shadow-lg">
              {session?.user?.name?.[0]?.toUpperCase() || "U"}
            </div>

            {/* User Info */}
            <div className="flex-1 text-center md:text-left">
              <h2 className="text-3xl font-bold text-gray-900">{session?.user?.name}</h2>
              <p className="text-gray-500 mt-1 flex items-center justify-center md:justify-start gap-2">
                <FiMapPin /> {form.location || "Location not set"}
              </p>
            </div>

            {/* Edit Button */}
            <button
              onClick={() => setEditing(true)}
              className="bg-indigo-600 text-white px-6 py-2 rounded-full font-semibold hover:bg-indigo-700 transition flex items-center gap-2"
            >
              <FiEdit /> Edit Profile
            </button>
          </div>

          {/* Stats */}
          <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-gray-50 rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-indigo-600">{stats.rentals}</p>
              <p className="text-sm text-gray-500">Total Rentals</p>
            </div>
            <div className="bg-gray-50 rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-indigo-600">{stats.rating}</p>
              <p className="text-sm text-gray-500">Rating</p>
            </div>
            {session?.user?.role === "TRADESMAN" && (
              <div className="bg-gray-50 rounded-xl p-4 text-center">
                <p className="text-2xl font-bold text-indigo-600">{stats.toolsListed}</p>
                <p className="text-sm text-gray-500">Tools Listed</p>
              </div>
            )}
            <div className="bg-gray-50 rounded-xl p-4 text-center">
              <p className="text-2xl font-bold text-indigo-600">{stats.memberSince}</p>
              <p className="text-sm text-gray-500">Member Since</p>
            </div>
          </div>
        </div>
      </div>

      {/* Contact Info Box */}
      <div className="max-w-4xl mx-auto mt-8 bg-white rounded-3xl shadow-md p-6">
        <h3 className="text-xl font-bold mb-4">Contact Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <p className="flex items-center gap-3 text-gray-700">
            <FiMail className="text-indigo-600" /> {session?.user?.email}
          </p>
          <p className="flex items-center gap-3 text-gray-700">
            <FiPhone className="text-indigo-600" /> {form.phone || "Not set"}
          </p>
        </div>
      </div>
    </div>
  );
}
