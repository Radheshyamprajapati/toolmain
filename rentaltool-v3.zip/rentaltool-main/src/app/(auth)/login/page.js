"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { FiLock, FiMail, FiTool, FiArrowRight, FiShield, FiClock, FiMapPin } from "react-icons/fi";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const res = await signIn("credentials", {
      redirect: false,
      email,
      password,
    });

    if (res?.error) {
      setError("Invalid email or password");
      setLoading(false);
    } else {
      router.push("/tools");
    }
  }

  return (
    <div className="min-h-screen flex bg-gray-50">
      {/* LEFT IMAGE PANEL (hidden on mobile) */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden">
        {/* Background image with overlay */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?w=1200&q=80')",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/80 via-purple-900/70 to-black/80" />

        {/* Logo and branding */}
        <div className="relative z-10 p-12 flex flex-col justify-between w-full">
          <div className="flex items-center gap-2 text-white">
            <div className="bg-white/10 backdrop-blur p-3 rounded-xl">
              <FiTool className="w-8 h-8 text-white" />
            </div>
            <span className="text-3xl font-extrabold tracking-tight">ToolHive</span>
          </div>

          <div>
            <h1 className="text-4xl font-extrabold text-white leading-tight">
              Rent Tools.
              <br />
              Get the Job Done.
            </h1>
            <p className="mt-4 text-white/80 max-w-md">
              Connect with verified electricians, builders, and mechanics. Rent or buy
              professional equipment easily.
            </p>

            {/* Feature bullets */}
            <div className="mt-8 space-y-3 text-white/90">
              <p className="flex items-center gap-3">
                <FiShield className="w-5 h-5 text-green-400" />
                Verified professionals & tools
              </p>
              <p className="flex items-center gap-3">
                <FiClock className="w-5 h-5 text-yellow-400" />
                Rent by day, week, or month
              </p>
              <p className="flex items-center gap-3">
                <FiMapPin className="w-5 h-5 text-pink-400" />
                Tools near you
              </p>
            </div>
          </div>

          {/* Gallery of tools */}
          <div className="grid grid-cols-3 gap-4">
            <img
              src="https://images.unsplash.com/photo-1504148455328-c376907d081c?w=200&q=80"
              alt="Electrical tools"
              className="h-20 w-full object-cover rounded-xl border-2 border-white/30"
            />
            <img
              src="https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?w=200&q=80"
              alt="Construction tools"
              className="h-20 w-full object-cover rounded-xl border-2 border-white/30"
            />
            <img
              src="https://images.unsplash.com/photo-1517164852305-99a3e65bb47e?w=200&q=80"
              alt="Mechanic tools"
              className="h-20 w-full object-cover rounded-xl border-2 border-white/30"
            />
          </div>
        </div>
      </div>

      {/* RIGHT SIDE – LOGIN FORM */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12">
        <div className="w-full max-w-md">
          {/* Mobile logo */}
          <div className="flex items-center justify-center lg:hidden mb-8">
            <div className="bg-indigo-600 p-3 rounded-xl">
              <FiTool className="w-8 h-8 text-white" />
            </div>
            <span className="text-3xl font-extrabold text-gray-900 ml-2">ToolHive</span>
          </div>

          <h2 className="text-3xl font-bold text-gray-900 text-center lg:text-left">
            Welcome Back
          </h2>
          <p className="mt-2 text-gray-600 text-center lg:text-left">
            Sign in to rent tools or manage your listings.
          </p>

          {error && (
            <div className="mt-4 bg-red-50 text-red-600 p-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Email</label>
              <div className="relative mt-1">
                <FiMail className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  placeholder="you@example.com"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Password</label>
              <div className="relative mt-1">
                <FiLock className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                  placeholder="••••••••"
                  required
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-indigo-600 text-white py-3 px-4 rounded-xl font-semibold hover:bg-indigo-700 transition flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {loading ? "Signing in..." : "Sign In"}
              {!loading && <FiArrowRight />}
            </button>
          </form>

          {/* Demo credentials */}
          <div className="mt-6 p-4 bg-indigo-50 rounded-xl border border-indigo-100">
            <p className="text-sm font-semibold text-indigo-900">Demo Users</p>
            <p className="text-xs text-indigo-700 mt-1">john@demo.com / demo1234 (Tradesman)</p>
            <p className="text-xs text-indigo-700">tom@demo.com / demo1234 (Customer)</p>
          </div>

          <p className="mt-6 text-center text-sm text-gray-600">
            Don't have an account?{" "}
            <Link href="/register" className="font-medium text-indigo-600 hover:text-indigo-500">
              Register free
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
