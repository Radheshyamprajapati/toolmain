import bcrypt from "bcryptjs";
import { prisma } from "@/lib/prisma";

export const runtime = "nodejs";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export async function POST(req) {
  try {
    const body = await req.json();
    const {
      name,
      email,
      password,
      phone,
      location,
      role = "USER",
      businessName,
      gstNumber,
    } = body || {};

    if (!name || !name.trim()) {
      return Response.json({ error: "Name is required" }, { status: 400 });
    }
    if (!email || !EMAIL_RE.test(email)) {
      return Response.json({ error: "A valid email is required" }, { status: 400 });
    }
    if (!password || password.length < 6) {
      return Response.json(
        { error: "Password must be at least 6 characters" },
        { status: 400 }
      );
    }

    const normalizedRole = role === "TRADESMAN" ? "TRADESMAN" : "USER";
    const normalizedEmail = email.toLowerCase().trim();

    const existing = await prisma.user.findUnique({ where: { email: normalizedEmail } });
    if (existing) {
      return Response.json({ error: "An account with this email already exists" }, { status: 409 });
    }

    const hashed = bcrypt.hashSync(password, 10);

    // Anyone registering as a TRADESMAN (equipment/tool owner) is applying
    // to become an "Authorised Provider". They can sign in immediately, but
    // cannot list tools until an admin approves the application.
    const isProviderApplication = normalizedRole === "TRADESMAN";

    const user = await prisma.user.create({
      data: {
        name: name.trim(),
        email: normalizedEmail,
        password: hashed,
        role: normalizedRole,
        phone: phone || null,
        location: location || null,
        providerStatus: isProviderApplication ? "PENDING" : "NONE",
        businessName: isProviderApplication ? businessName || null : null,
        gstNumber: isProviderApplication ? gstNumber || null : null,
        providerAppliedAt: isProviderApplication ? new Date() : null,
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        providerStatus: true,
      },
    });

    // Notify all admins that a new provider wants to be verified.
    if (isProviderApplication) {
      try {
        const admins = await prisma.user.findMany({
          where: { role: "ADMIN" },
          select: { id: true },
        });
        if (admins.length) {
          const { createNotification } = await import("@/lib/notifications");
          await Promise.all(
            admins.map((admin) =>
              createNotification({
                userId: admin.id,
                type: "BOOKING_REQUESTED",
                title: "New provider application",
                message: `${user.name} applied to become an authorised equipment provider.`,
                dedupeKey: `provider_application_${user.id}`,
                sendPush: false,
              })
            )
          );
        }
      } catch (e) {
        console.error("Admin notification on registration failed:", e);
      }
    }

    return Response.json({ success: true, user }, { status: 201 });
  } catch (err) {
    console.error("POST /api/auth/register error:", err);
    return Response.json({ error: "Registration failed. Please try again." }, { status: 500 });
  }
}
