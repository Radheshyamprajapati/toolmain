import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET(req) {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== "ADMIN") {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { searchParams } = new URL(req.url);
  const status = searchParams.get("status"); // PENDING | APPROVED | REJECTED | SUSPENDED

  const where = { role: "TRADESMAN" };
  if (status) where.providerStatus = status;
  else where.providerStatus = { not: "NONE" };

  const providers = await prisma.user.findMany({
    where,
    select: {
      id: true,
      name: true,
      email: true,
      phone: true,
      location: true,
      businessName: true,
      gstNumber: true,
      providerStatus: true,
      providerAppliedAt: true,
      providerReviewedAt: true,
      providerNote: true,
      createdAt: true,
      _count: { select: { tools: true } },
    },
    orderBy: { providerAppliedAt: "desc" },
  });

  return Response.json(providers);
}
