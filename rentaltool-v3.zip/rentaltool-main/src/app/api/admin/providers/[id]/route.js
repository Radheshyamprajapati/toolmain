import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createNotification } from "@/lib/notifications";

const ALLOWED = ["APPROVED", "REJECTED", "SUSPENDED", "PENDING"];

export async function PATCH(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== "ADMIN") {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const { status, note } = await req.json();
  if (!ALLOWED.includes(status)) {
    return Response.json({ error: "Invalid status" }, { status: 400 });
  }

  const provider = await prisma.user.findUnique({ where: { id: params.id } });
  if (!provider || provider.role !== "TRADESMAN") {
    return Response.json({ error: "Provider not found" }, { status: 404 });
  }

  const updated = await prisma.user.update({
    where: { id: params.id },
    data: {
      providerStatus: status,
      providerReviewedAt: new Date(),
      providerNote: note || null,
    },
  });

  // If rejected/suspended, immediately hide their tools from the public catalog.
  if (status === "REJECTED" || status === "SUSPENDED") {
    await prisma.tool.updateMany({
      where: { ownerId: provider.id },
      data: { isAvailable: false },
    });
  }

  try {
    if (status === "APPROVED") {
      await createNotification({
        userId: provider.id,
        type: "PROVIDER_APPROVED",
        title: "You're now an Authorised Provider",
        message: "Your provider application was approved. You can list tools and equipment now.",
        dedupeKey: `provider_review_${provider.id}_${Date.now()}`,
      });
    } else if (status === "REJECTED") {
      await createNotification({
        userId: provider.id,
        type: "PROVIDER_REJECTED",
        title: "Provider application update",
        message: note
          ? `Your provider application was not approved: ${note}`
          : "Your provider application was not approved.",
        dedupeKey: `provider_review_${provider.id}_${Date.now()}`,
      });
    }
  } catch (e) {
    console.error("Provider review notification failed:", e);
  }

  return Response.json({
    id: updated.id,
    name: updated.name,
    email: updated.email,
    providerStatus: updated.providerStatus,
  });
}
