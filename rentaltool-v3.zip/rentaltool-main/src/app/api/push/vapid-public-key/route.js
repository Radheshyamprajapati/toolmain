export async function GET() {
  if (!process.env.VAPID_PUBLIC_KEY) {
    return new Response("VAPID not configured", { status: 500 });
  }
  return new Response(process.env.VAPID_PUBLIC_KEY);
}
