import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";
import { createNotification } from "@/lib/notifications";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

function generateOtp() {
  return String(Math.floor(1000 + Math.random() * 9000));
}

export async function POST(req) {
  const sig = req.headers.get("stripe-signature");
  const body = await req.text();

  let event;
  try {
    event = stripe.webhooks.constructEvent(body, sig, process.env.STRIPE_WEBHOOK_SECRET);
  } catch (err) {
    console.error("Stripe webhook signature verification failed:", err.message);
    return Response.json({ error: err.message }, { status: 400 });
  }

  try {
    if (event.type === "checkout.session.completed") {
      if (event.data.object.metadata?.kind === "extension") {
        await handleExtensionCompleted(event.data.object);
      } else {
        await handleCheckoutCompleted(event.data.object);
      }
    } else if (event.type === "checkout.session.expired") {
      await handleCheckoutExpired(event.data.object);
    } else if (event.type === "charge.refunded") {
      await handleChargeRefunded(event.data.object);
    }
  } catch (err) {
    // Returning 500 tells Stripe to retry the webhook later.
    console.error(`Error handling Stripe event ${event.type}:`, err);
    return Response.json({ error: "Webhook handler failed" }, { status: 500 });
  }

  return Response.json({ received: true });
}

async function handleExtensionCompleted(sessionData) {
  const rentalId = sessionData.metadata?.rentalId;
  if (!rentalId) return;
  const rental = await prisma.rental.findUnique({ where: { id: rentalId }, include: { tool: true } });
  if (!rental) return;
  // Idempotent: nothing pending for this session means it was already applied.
  if (!rental.pendingExtensionEndDate || rental.pendingExtensionCheckoutId !== sessionData.id) return;

  const extra = rental.pendingExtensionAmount || 0;
  await prisma.$transaction([
    prisma.rental.update({
      where: { id: rentalId },
      data: {
        endDate: rental.pendingExtensionEndDate,
        rentalAmount: rental.rentalAmount + extra,
        totalAmount: rental.totalAmount + extra,
        pendingExtensionEndDate: null,
        pendingExtensionAmount: null,
        pendingExtensionCheckoutId: null,
      },
    }),
    prisma.rentalStatusHistory.create({
      data: {
        rentalId,
        oldStatus: rental.status,
        newStatus: rental.status,
        notes: `Rental extended to ${new Date(rental.pendingExtensionEndDate).toLocaleDateString()}`,
      },
    }),
  ]);

  try {
    await createNotification({
      userId: rental.tool.ownerId,
      type: "PAYMENT_RECEIVED",
      title: "Rental extended",
      message: `${rental.tool.name} was extended.`,
      toolId: rental.toolId,
      rentalId,
      dedupeKey: `extension_paid_${rentalId}_${sessionData.id}`,
    });
  } catch (e) {
    console.error(e);
  }
}

async function handleCheckoutCompleted(sessionData) {
  const rentalId = sessionData.metadata?.rentalId;
  if (!rentalId) {
    console.warn("checkout.session.completed with no rentalId in metadata:", sessionData.id);
    return;
  }

  const rental = await prisma.rental.findUnique({
    where: { id: rentalId },
    include: { tool: { include: { owner: true } } },
  });
  if (!rental) {
    console.warn(`checkout.session.completed for unknown rental ${rentalId}`);
    return;
  }

  // Idempotency guard — Stripe may deliver this event more than once.
  if (rental.paymentStatus === "SUCCESS") return;

  const paymentIntentId =
    typeof sessionData.payment_intent === "string"
      ? sessionData.payment_intent
      : sessionData.payment_intent?.id || null;

  await prisma.$transaction([
    prisma.rental.update({
      where: { id: rentalId },
      data: {
        paymentStatus: "SUCCESS",
        status: "PENDING_VENDOR_ACCEPTANCE",
        paidAt: new Date(),
        paymentIntentId,
        otpCode: generateOtp(),
      },
    }),
    prisma.rentalStatusHistory.create({
      data: {
        rentalId,
        oldStatus: "PENDING_PAYMENT",
        newStatus: "PENDING_VENDOR_ACCEPTANCE",
        notes: "Payment confirmed via Stripe Checkout",
      },
    }),
  ]);

  // A purchase reserves the item immediately so nobody else can buy or rent it.
  if (rental.transactionType === "BUY") {
    await prisma.tool.update({ where: { id: rental.toolId }, data: { isAvailable: false } });
  }

  // Second line of defense against double-booking: now that this booking is
  // definitively paid, sweep away any other still-unpaid bookings for the
  // same tool that would otherwise collide with it, so nobody can pay for a
  // slot that's already gone. (The primary defense is the transactional
  // overlap check at booking time — this closes the remaining race where
  // two people both got past that check before either paid.)
  await cancelConflictingPendingRentals(rental);

  try {
    await createNotification({
      userId: rental.tool.ownerId,
      type: "PAYMENT_RECEIVED",
      title: rental.transactionType === "BUY" ? "Purchase paid — action needed" : "Rental paid — action needed",
      message: `Payment received for ${rental.tool.name}. Please review and accept the booking.`,
      toolId: rental.toolId,
      rentalId: rental.id,
      dedupeKey: `payment_received_owner_${rental.id}`,
    });
    await createNotification({
      userId: rental.renterId,
      type: "PAYMENT_RECEIVED",
      title: "Payment successful",
      message: `Your payment for ${rental.tool.name} was successful. Waiting on the provider to accept.`,
      toolId: rental.toolId,
      rentalId: rental.id,
      dedupeKey: `payment_received_renter_${rental.id}`,
      sendPush: false,
    });
  } catch (e) {
    console.error("Payment-confirmation notification failed:", e);
  }
}

async function cancelConflictingPendingRentals(paidRental) {
  const where =
    paidRental.transactionType === "BUY"
      ? {
          toolId: paidRental.toolId,
          transactionType: "BUY",
          status: "PENDING_PAYMENT",
          id: { not: paidRental.id },
        }
      : {
          toolId: paidRental.toolId,
          status: "PENDING_PAYMENT",
          id: { not: paidRental.id },
          startDate: { lte: paidRental.endDate },
          endDate: { gte: paidRental.startDate },
        };

  const conflicting = await prisma.rental.findMany({ where });
  if (!conflicting.length) return;

  for (const loser of conflicting) {
    if (loser.checkoutSessionId) {
      try {
        await stripe.checkout.sessions.expire(loser.checkoutSessionId);
      } catch (e) {
        // already expired/paid/gone — fine
      }
    }

    await prisma.$transaction([
      prisma.rental.update({
        where: { id: loser.id },
        data: {
          status: "CANCELLED",
          cancelledAt: new Date(),
          cancelReason: "Another customer completed payment for this item/slot first",
        },
      }),
      prisma.rentalStatusHistory.create({
        data: {
          rentalId: loser.id,
          oldStatus: loser.status,
          newStatus: "CANCELLED",
          notes: "Auto-cancelled: lost the race to another paid booking",
        },
      }),
    ]);

    try {
      await createNotification({
        userId: loser.renterId,
        type: "RENTAL_CANCELLED",
        title: "Booking no longer available",
        message: "Sorry — another customer completed payment for this item just before you. You have not been charged.",
        rentalId: loser.id,
        dedupeKey: `lost_race_${loser.id}`,
      });
    } catch (e) {
      console.error(e);
    }
  }
}

async function handleCheckoutExpired(sessionData) {
  const rentalId = sessionData.metadata?.rentalId;
  if (!rentalId) return;

  const rental = await prisma.rental.findUnique({ where: { id: rentalId } });
  if (!rental || rental.status !== "PENDING_PAYMENT") return;

  await prisma.$transaction([
    prisma.rental.update({
      where: { id: rentalId },
      data: {
        status: "CANCELLED",
        cancelledAt: new Date(),
        cancelReason: "Payment window expired",
      },
    }),
    prisma.rentalStatusHistory.create({
      data: {
        rentalId,
        oldStatus: "PENDING_PAYMENT",
        newStatus: "CANCELLED",
        notes: "Checkout session expired without payment",
      },
    }),
  ]);
}

async function handleChargeRefunded(charge) {
  const paymentIntentId = charge.payment_intent;
  if (!paymentIntentId) return;

  const rental = await prisma.rental.findFirst({ where: { paymentIntentId } });
  if (!rental || rental.paymentStatus === "REFUNDED") return;

  const fullyRefunded = charge.amount_refunded >= charge.amount;
  await prisma.rental.update({
    where: { id: rental.id },
    data: {
      paymentStatus: fullyRefunded ? "REFUNDED" : "PARTIALLY_REFUNDED",
      refundedAt: new Date(),
      refundAmount: charge.amount_refunded / 100,
    },
  });
}
