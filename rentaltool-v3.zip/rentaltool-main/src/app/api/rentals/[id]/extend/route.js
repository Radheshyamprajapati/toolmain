import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";
import { calcRentalDaysCeil, commissionOn } from "@/lib/pricing";

const CURRENCY = process.env.STRIPE_CURRENCY || "inr";
const BLOCKING = ["PENDING_PAYMENT","PAYMENT_SUCCESS","PENDING_VENDOR_ACCEPTANCE","ACCEPTED","PREPARING","READY","OUT_FOR_DELIVERY","ACTIVE"];

export async function POST(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const { newEndDate } = await req.json();
  const newEnd = new Date(newEndDate);
  if (isNaN(newEnd.getTime())) return Response.json({ error: "Invalid date" }, { status: 400 });

  const rental = await prisma.rental.findUnique({ where: { id: params.id }, include: { tool: true } });
  if (!rental) return Response.json({ error: "Not found" }, { status: 404 });
  if (rental.renterId !== session.user.id) return Response.json({ error: "Forbidden" }, { status: 403 });
  if (rental.transactionType !== "RENT") return Response.json({ error: "Purchases can't be extended" }, { status: 400 });
  if (rental.status !== "ACTIVE") return Response.json({ error: "Only an active rental can be extended" }, { status: 400 });
  if (newEnd <= new Date(rental.endDate)) {
    return Response.json({ error: "New end date must be after the current end date" }, { status: 400 });
  }

  // The extra days must be free of other bookings and owner-blocked dates.
  const conflict = await prisma.rental.findFirst({
    where: {
      toolId: rental.toolId,
      id: { not: rental.id },
      status: { in: BLOCKING },
      startDate: { lte: newEnd },
      endDate: { gte: rental.endDate },
    },
    select: { id: true },
  });
  if (conflict) return Response.json({ error: "Someone else has this item booked right after your current end date" }, { status: 409 });
  const blocked = await prisma.blockedDate.findFirst({
    where: { toolId: rental.toolId, startDate: { lte: newEnd }, endDate: { gte: rental.endDate } },
    select: { id: true },
  });
  if (blocked) return Response.json({ error: "The provider has blocked those dates" }, { status: 409 });

  const extraDays = calcRentalDaysCeil(new Date(rental.endDate), newEnd);
  const extraRental = extraDays * rental.tool.pricePerDay;
  const extraTotal = extraRental + commissionOn(extraRental);

  let checkout;
  try {
    checkout = await stripe.checkout.sessions.create({
      payment_method_types: ["card", ...(process.env.STRIPE_ENABLE_UPI !== "false" ? ["upi"] : [])],
      line_items: [{
        price_data: {
          currency: CURRENCY,
          product_data: {
            name: `Extend rental: ${rental.tool.name}`,
            description: `${extraDays} extra day(s), until ${newEnd.toLocaleDateString()}`,
          },
          unit_amount: Math.round(extraTotal * 100),
        },
        quantity: 1,
      }],
      mode: "payment",
      customer_email: session.user.email || undefined,
      success_url: `${process.env.NEXTAUTH_URL}/rentals?extended=true`,
      cancel_url: `${process.env.NEXTAUTH_URL}/rentals`,
      metadata: { rentalId: rental.id, kind: "extension" },
      expires_at: Math.floor(Date.now() / 1000) + 30 * 60,
    });
  } catch (e) {
    console.error("Extension checkout failed:", e.message);
    return Response.json({ error: "Could not start payment for the extension" }, { status: 502 });
  }

  await prisma.rental.update({
    where: { id: rental.id },
    data: { pendingExtensionEndDate: newEnd, pendingExtensionAmount: extraTotal, pendingExtensionCheckoutId: checkout.id },
  });
  return Response.json({ url: checkout.url, extraDays, extraTotal });
}
