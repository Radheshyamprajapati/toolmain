import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function GET(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const rental = await prisma.rental.findUnique({
    where: { id: params.id },
    include: { tool: true, delivery: true },
  });
  if (!rental) return Response.json({ error: "Not found" }, { status: 404 });

  const isOwner = rental.tool.ownerId === session.user.id;
  const isRenter = rental.renterId === session.user.id;
  if (!isOwner && !isRenter && session.user.role !== "ADMIN") {
    return Response.json({ error: "Forbidden" }, { status: 403 });
  }

  if (!rental.delivery) {
    return Response.json({ delivery: null, pickupType: rental.pickupType });
  }

  return Response.json({ delivery: rental.delivery, pickupType: rental.pickupType });
}
