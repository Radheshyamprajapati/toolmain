import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createNotification } from "@/lib/notifications";

export async function POST(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const rental = await prisma.rental.findUnique({
    where: { id: params.id },
    include: { tool: true },
  });

  if (!rental || rental.tool.ownerId !== session.user.id) {
    return Response.json({ error: "Not your rental" }, { status: 403 });
  }

  if (rental.status !== "PENDING_VENDOR_ACCEPTANCE") {
    return Response.json({ error: "Invalid status" }, { status: 400 });
  }
  if (rental.paymentStatus !== "SUCCESS") {
    return Response.json({ error: "Payment has not been confirmed yet" }, { status: 400 });
  }

  await prisma.$transaction([
    prisma.rental.update({
      where: { id: rental.id },
      data: { status: "ACCEPTED" },
    }),
    prisma.rentalStatusHistory.create({
      data: { rentalId: rental.id, newStatus: "ACCEPTED", oldStatus: "PENDING_VENDOR_ACCEPTANCE" },
    }),
  ]);

  try {
    await createNotification({
      userId: rental.renterId,
      type: "BOOKING_ACCEPTED",
      title: "Booking accepted",
      message: `${rental.tool.name} — your booking was accepted by the provider.`,
      toolId: rental.toolId,
      rentalId: rental.id,
      dedupeKey: `status_${rental.id}_ACCEPTED`,
    });
  } catch (e) {
    console.error(e);
  }

  return Response.json({ success: true });
}
