import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { stripe } from "@/lib/stripe";
import { createNotification } from "@/lib/notifications";

export async function GET(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const rental = await prisma.rental.findUnique({
    where: { id: params.id },
    include: {
      tool: { include: { owner: { select: { id: true, name: true, phone: true } } } },
      renter: { select: { id: true, name: true, email: true, phone: true } },
      delivery: true,
      history: { orderBy: { createdAt: "asc" } },
    },
  });

  if (!rental) return Response.json({ error: "Not Found" }, { status: 404 });

  const isOwner = rental.tool.ownerId === session.user.id;
  const isRenter = rental.renterId === session.user.id;
  if (!isOwner && !isRenter && session.user.role !== "ADMIN") {
    return Response.json({ error: "Forbidden" }, { status: 403 });
  }

  return Response.json(rental);
}

// Only a small, explicit set of pre-payment fields can be edited here.
// Every status transition (accept/prepare/ship/deliver/cancel/etc.) MUST go
// through /api/rentals/[id]/status, which enforces the state machine,
// triggers delivery-partner assignment, refunds, and notifications.
const EDITABLE_FIELDS = ["pickupType", "deliveryAddress"];

export async function PUT(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const rental = await prisma.rental.findUnique({ where: { id: params.id } });
  if (!rental) return Response.json({ error: "Not Found" }, { status: 404 });

  const isRenter = rental.renterId === session.user.id;
  if (!isRenter) {
    return Response.json({ error: "Forbidden" }, { status: 403 });
  }

  if (rental.status !== "PENDING_PAYMENT") {
    return Response.json(
      { error: "This booking can no longer be edited — it's already been paid or is in progress." },
      { status: 400 }
    );
  }

  const data = {};
  for (const field of EDITABLE_FIELDS) {
    if (body[field] !== undefined) data[field] = body[field];
  }
  if (Object.keys(data).length === 0) {
    return Response.json({ error: "No editable fields provided" }, { status: 400 });
  }
  if (data.pickupType === "DELIVERY" && !(data.deliveryAddress || rental.deliveryAddress)) {
    return Response.json({ error: "A delivery address is required" }, { status: 400 });
  }

  const updated = await prisma.rental.update({ where: { id: params.id }, data });
  return Response.json(updated);
}

// Cancelling before payment (or before vendor acceptance) is a simple
// delete; anything already paid must go through the status endpoint so a
// refund is actually issued.
export async function DELETE(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const rental = await prisma.rental.findUnique({
    where: { id: params.id },
    include: { tool: true },
  });
  if (!rental) return Response.json({ error: "Not Found" }, { status: 404 });

  const isOwner = rental.tool.ownerId === session.user.id;
  const isRenter = rental.renterId === session.user.id;
  if (!isOwner && !isRenter) {
    return Response.json({ error: "Forbidden" }, { status: 403 });
  }

  if (rental.paymentStatus === "SUCCESS") {
    return Response.json(
      { error: "This booking has already been paid. Cancel it instead so a refund can be issued." },
      { status: 400 }
    );
  }

  // If a Stripe Checkout Session was opened but never paid, expire it so it
  // can't be paid after we've deleted the local record.
  if (rental.checkoutSessionId && rental.paymentStatus !== "SUCCESS") {
    try {
      await stripe.checkout.sessions.expire(rental.checkoutSessionId);
    } catch (e) {
      // Already expired/completed/doesn't exist — safe to ignore.
    }
  }

  await prisma.rentalStatusHistory.deleteMany({ where: { rentalId: rental.id } });
  await prisma.rental.delete({ where: { id: params.id } });

  if (isRenter) {
    try {
      await createNotification({
        userId: rental.tool.ownerId,
        type: "RENTAL_CANCELLED",
        title: "Booking cancelled",
        message: `A pending booking for ${rental.tool.name} was cancelled by the customer.`,
        toolId: rental.toolId,
        dedupeKey: `booking_deleted_${rental.id}`,
        sendPush: false,
      });
    } catch (e) {
      console.error(e);
    }
  }

  return new Response(null, { status: 204 });
}
