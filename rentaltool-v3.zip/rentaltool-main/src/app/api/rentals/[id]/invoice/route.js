import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const GST_RATE = Number(process.env.GST_RATE || 18);
const PLATFORM_NAME = process.env.PLATFORM_NAME || "ToolHive";
const PLATFORM_GSTIN = process.env.PLATFORM_GSTIN || "";

const esc = (s) =>
  String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const money = (n) => `Rs ${Number(n || 0).toFixed(2)}`;
const day = (d) => new Date(d).toLocaleDateString("en-IN");

export async function GET(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const r = await prisma.rental.findUnique({
    where: { id: params.id },
    include: { tool: { include: { owner: true } }, renter: true },
  });
  if (!r) return Response.json({ error: "Not found" }, { status: 404 });

  // Admins may view invoices for monitoring; only the two parties otherwise.
  const allowed = r.renterId === session.user.id || r.tool.ownerId === session.user.id || session.user.role === "ADMIN";
  if (!allowed) return Response.json({ error: "Forbidden" }, { status: 403 });
  if (!["SUCCESS", "REFUNDED", "PARTIALLY_REFUNDED"].includes(r.paymentStatus)) {
    return Response.json({ error: "No invoice until this booking is paid" }, { status: 400 });
  }

  // Prices are tax-inclusive. GST applies to rental/sale amount and delivery
  // (net of coupon); the refundable security deposit is not a taxable supply.
  const taxable = Math.max(0, r.rentalAmount - (r.discountAmount || 0) + r.deliveryFee);
  const gst = Math.round(((taxable * GST_RATE) / (100 + GST_RATE)) * 100) / 100;
  const base = Math.round((taxable - gst) * 100) / 100;
  const cgst = Math.round((gst / 2) * 100) / 100;
  const sgst = Math.round((gst - cgst) * 100) / 100;
  const invoiceNo = `INV-${r.id.slice(-8).toUpperCase()}`;

  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${esc(invoiceNo)}</title>
<style>
body{font-family:-apple-system,Segoe UI,Roboto,sans-serif;color:#1f2937;max-width:720px;margin:40px auto;padding:0 20px}
.muted{color:#6b7280;font-size:13px}.row{display:flex;gap:24px;margin-top:24px}.box{flex:1}
.box h3{font-size:12px;text-transform:uppercase;color:#6b7280;margin:0 0 4px}
table{width:100%;border-collapse:collapse;margin-top:28px}
th,td{text-align:left;padding:8px 6px;border-bottom:1px solid #e5e7eb;font-size:14px}
th{color:#6b7280;font-size:12px;text-transform:uppercase}.num{text-align:right}
.total td{font-weight:700;font-size:16px;border-top:2px solid #1f2937;border-bottom:none}
@media print{.no-print{display:none}}
</style></head><body>
<button class="no-print" onclick="window.print()" style="float:right;padding:8px 14px;background:#4f46e5;color:#fff;border:0;border-radius:6px;cursor:pointer">Print / Save PDF</button>
<h2 style="margin:0">${esc(PLATFORM_NAME)}</h2>
<p class="muted">Tax invoice${PLATFORM_GSTIN ? ` &middot; GSTIN ${esc(PLATFORM_GSTIN)}` : ""}</p>
<div class="row">
 <div class="box"><h3>Invoice</h3>${esc(invoiceNo)}<br>${esc(day(r.paidAt || r.createdAt))}<br><span class="muted">${esc(r.transactionType)} &middot; ${esc(r.paymentStatus)}</span>${r.paymentIntentId ? `<br><span class="muted">Payment ${esc(r.paymentIntentId)}</span>` : ""}</div>
 <div class="box"><h3>Provider</h3>${esc(r.tool.owner.businessName || r.tool.owner.name)}<br>${esc(r.tool.owner.email)}${r.tool.owner.gstNumber ? `<br>GSTIN ${esc(r.tool.owner.gstNumber)}` : ""}</div>
 <div class="box"><h3>Billed to</h3>${esc(r.renter.name)}<br>${esc(r.renter.email)}${r.deliveryAddress ? `<br>${esc(r.deliveryAddress)}` : ""}</div>
</div>
<table><thead><tr><th>Description</th><th class="num">Amount</th></tr></thead><tbody>
<tr><td>${esc(r.tool.name)} ${r.transactionType === "RENT" ? `(${esc(day(r.startDate))} - ${esc(day(r.endDate))})` : "(purchase)"}</td><td class="num">${money(r.rentalAmount)}</td></tr>
${r.discountAmount > 0 ? `<tr><td>Coupon ${esc(r.couponCode || "")}</td><td class="num">-${money(r.discountAmount)}</td></tr>` : ""}
${r.deliveryFee > 0 ? `<tr><td>Delivery fee</td><td class="num">${money(r.deliveryFee)}</td></tr>` : ""}
<tr><td>Taxable value</td><td class="num">${money(base)}</td></tr>
<tr><td>CGST @ ${(GST_RATE / 2).toFixed(1)}%</td><td class="num">${money(cgst)}</td></tr>
<tr><td>SGST @ ${(GST_RATE / 2).toFixed(1)}%</td><td class="num">${money(sgst)}</td></tr>
<tr><td>Platform fee</td><td class="num">${money(r.platformFee)}</td></tr>
${r.securityDeposit > 0 ? `<tr><td>Refundable security deposit (not taxable)</td><td class="num">${money(r.securityDeposit)}</td></tr>` : ""}
<tr class="total"><td>Total paid</td><td class="num">${money(r.totalAmount)}</td></tr>
</tbody></table>
${r.depositRefundStatus === "REFUNDED" ? `<p class="muted">Security deposit refunded on ${esc(day(r.depositRefundedAt))}.</p>` : ""}
${r.depositRefundStatus === "FORFEITED" ? `<p class="muted">Security deposit withheld: ${esc(r.depositForfeitReason || "")}.</p>` : ""}
<p class="muted" style="margin-top:32px">System-generated invoice. GST figures are illustrative for MVP use; confirm tax treatment with a professional before commercial use.</p>
</body></html>`;

  return new Response(html, { headers: { "Content-Type": "text/html; charset=utf-8" } });
}
