import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { stripe } from "@/lib/stripe";
import { createNotification } from "@/lib/notifications";
import { assignDeliveryPartner, appendDeliveryEvent } from "@/lib/delivery";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Allowed transitions per role, adapted for BUY vs RENT (a purchase has no
// return leg — it goes straight from "delivered" to COMPLETED).
function buildTransitions(transactionType) {
  const isBuy = transactionType === "BUY";

  const VENDOR = {
    PENDING_VENDOR_ACCEPTANCE: ["ACCEPTED", "CANCELLED"],
    ACCEPTED: ["PREPARING", "CANCELLED"],
    PREPARING: ["READY", "CANCELLED"],
    READY: ["OUT_FOR_DELIVERY", "CANCELLED"],
    OUT_FOR_DELIVERY: ["ACTIVE", "CANCELLED"],
    ACTIVE: isBuy ? ["COMPLETED"] : ["RETURN_REQUESTED", "CANCELLED"],
    ...(isBuy
      ? {}
      : {
          RETURN_REQUESTED: ["RETURNED"],
          RETURNED: ["INSPECTION"],
          INSPECTION: ["COMPLETED"],
        }),
  };

  const RENTER = {
    PENDING_VENDOR_ACCEPTANCE: ["CANCELLED"],
    PENDING_PAYMENT: ["CANCELLED"],
    ACCEPTED: ["CANCELLED"],
    PREPARING: ["CANCELLED"],
    READY: ["CANCELLED"],
    OUT_FOR_DELIVERY: ["CANCELLED"],
    ...(isBuy ? {} : { ACTIVE: ["RETURN_REQUESTED"] }),
  };

  return { VENDOR, RENTER, ADMIN: {} };
}

// Handover checkpoints where we require the shared OTP as a lightweight
// proof-of-handover (customer received the item / owner got it back).
const OTP_REQUIRED_FOR = ["ACTIVE", "RETURNED"];

export async function PATCH(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const rentalId = params.id;
  const { newStatus, otp, notes, reason, depositDecision, depositForfeitReason } = await req.json();

  const rental = await prisma.rental.findUnique({
    where: { id: rentalId },
    include: { tool: true, renter: true },
  });

  if (!rental) return Response.json({ error: "Rental not found" }, { status: 404 });

  const isOwner = rental.tool.ownerId === session.user.id;
  const isRenter = rental.renterId === session.user.id;

  let actorRole;
  if (session.user.role === "ADMIN") {
    return Response.json({ error: "Administrators cannot change rental status" }, { status: 403 });
  } else if (isOwner) actorRole = "VENDOR";
  else if (isRenter) actorRole = "RENTER";
  else return Response.json({ error: "Forbidden" }, { status: 403 });

  const transitions = buildTransitions(rental.transactionType);
  const allowedTransitions = transitions[actorRole]?.[rental.status] || [];
  if (!allowedTransitions.includes(newStatus)) {
    return Response.json(
      { error: `Cannot change status from ${rental.status} to ${newStatus}` },
      { status: 400 }
    );
  }

  if (rental.paymentStatus !== "SUCCESS" && newStatus !== "CANCELLED") {
    return Response.json(
      { error: "This booking has not been paid for yet." },
      { status: 400 }
    );
  }

  // OTP verification for handover checkpoints
  if (OTP_REQUIRED_FOR.includes(newStatus)) {
    if (!otp) return Response.json({ error: "OTP required" }, { status: 400 });
    if (otp !== rental.otpCode) {
      return Response.json({ error: "Invalid OTP" }, { status: 400 });
    }
  }

  const updateData = { status: newStatus };
  if (newStatus === "COMPLETED") updateData.completedAt = new Date();
  if (newStatus === "CANCELLED") {
    updateData.cancelledAt = new Date();
    updateData.cancelReason = reason || notes || null;
  }

  // --- Side effects per transition -----------------------------------
  let refundInfo = null;
  let deliveryInfo = null;

  if (newStatus === "CANCELLED" && rental.paymentStatus === "SUCCESS") {
    refundInfo = await issueRefund(rental);
    if (refundInfo.ok) {
      updateData.paymentStatus = "REFUNDED";
      updateData.refundedAt = new Date();
      updateData.refundAmount = rental.totalAmount;
      updateData.refundId = refundInfo.refundId;
    }
    // A purchase falling through cancels the sale — the item goes back on
    // the market. A rental never toggles tool availability.
    if (rental.transactionType === "BUY") {
      await prisma.tool.update({ where: { id: rental.toolId }, data: { isAvailable: true } });
    }
  }

  // Dispatching for home delivery hands the shipment to a delivery partner.
  if (newStatus === "OUT_FOR_DELIVERY" && rental.pickupType === "DELIVERY") {
    const delivery = await assignDeliveryPartner(rental);
    deliveryInfo = delivery;
  }

  // Handover confirmed — close out the delivery-partner shipment if there is one.
  if (newStatus === "ACTIVE" && rental.pickupType === "DELIVERY") {
    const existingDelivery = await prisma.delivery.findUnique({ where: { rentalId: rental.id } });
    if (existingDelivery) {
      await appendDeliveryEvent(existingDelivery.id, "DELIVERED", "Confirmed via handover OTP");
    }
  }
  if (newStatus === "RETURN_REQUESTED" && rental.pickupType === "DELIVERY") {
    const existingDelivery = await prisma.delivery.findUnique({ where: { rentalId: rental.id } });
    if (existingDelivery) {
      await appendDeliveryEvent(existingDelivery.id, "RETURN_PICKUP_SCHEDULED", "Return pickup requested");
    }
  }
  if (newStatus === "RETURNED" && rental.pickupType === "DELIVERY") {
    const existingDelivery = await prisma.delivery.findUnique({ where: { rentalId: rental.id } });
    if (existingDelivery) {
      await appendDeliveryEvent(existingDelivery.id, "RETURN_COMPLETED", "Confirmed via return OTP");
    }
  }

  // Automatic security-deposit settlement when a rental completes. The
  // provider may forfeit it for damage; otherwise it is refunded automatically.
  let depositInfo = null;
  if (newStatus === "COMPLETED" && rental.transactionType === "RENT" && rental.securityDeposit > 0) {
    if (actorRole === "VENDOR" && depositDecision === "FORFEIT") {
      updateData.depositRefundStatus = "FORFEITED";
      updateData.depositForfeitReason = depositForfeitReason || "Item returned damaged";
      depositInfo = { forfeited: true, reason: updateData.depositForfeitReason };
    } else {
      const refund = await issueDepositRefund(rental);
      if (refund.ok) {
        updateData.depositRefundStatus = "REFUNDED";
        updateData.depositRefundedAt = new Date();
        updateData.depositRefundId = refund.refundId;
      } else {
        updateData.depositRefundStatus = "PENDING"; // needs manual follow-up
      }
      depositInfo = refund;
    }
  }

  const [updated] = await prisma.$transaction([
    prisma.rental.update({ where: { id: rentalId }, data: updateData }),
    prisma.rentalStatusHistory.create({
      data: {
        rentalId,
        oldStatus: rental.status,
        newStatus,
        notes: notes || reason || "",
      },
    }),
  ]);

  await notifyStatusChange({ rental, newStatus, actorRole, refundInfo, depositInfo });

  return Response.json({ ...updated, delivery: deliveryInfo || undefined });
}

async function issueRefund(rental) {
  if (!rental.paymentIntentId) {
    console.warn(`Refund skipped for rental ${rental.id}: no paymentIntentId on file.`);
    return { ok: false, reason: "missing_payment_intent" };
  }
  try {
    const refund = await stripe.refunds.create({ payment_intent: rental.paymentIntentId });
    return { ok: true, refundId: refund.id };
  } catch (e) {
    console.error(`Stripe refund failed for rental ${rental.id}:`, e.message);
    return { ok: false, reason: e.message };
  }
}

async function notifyStatusChange({ rental, newStatus, actorRole, refundInfo, depositInfo }) {
  const messages = {
    ACCEPTED: {
      userId: rental.renterId,
      title: "Booking accepted",
      message: `${rental.tool.name} — your booking was accepted by the provider.`,
    },
    PREPARING: {
      userId: rental.renterId,
      title: "Getting ready",
      message: `${rental.tool.name} is being prepared for you.`,
    },
    READY: {
      userId: rental.renterId,
      title: "Ready for dispatch",
      message: `${rental.tool.name} is ready. It will be dispatched shortly.`,
    },
    OUT_FOR_DELIVERY: {
      userId: rental.renterId,
      type: "OUT_FOR_DELIVERY",
      title: "Out for delivery",
      message: `${rental.tool.name} is on its way to you.`,
    },
    ACTIVE: {
      userId: rental.renterId,
      type: "DELIVERED",
      title: rental.transactionType === "BUY" ? "Delivered" : "Rental started",
      message:
        rental.transactionType === "BUY"
          ? `${rental.tool.name} has been delivered. Enjoy!`
          : `${rental.tool.name} handover confirmed — your rental is now active.`,
    },
    RETURN_REQUESTED: {
      userId: rental.tool.ownerId,
      type: "RETURN_REQUESTED",
      title: "Return requested",
      message: `A return was requested for ${rental.tool.name}.`,
    },
    RETURNED: {
      userId: rental.tool.ownerId,
      type: "RETURN_CONFIRMED",
      title: "Item returned",
      message: `${rental.tool.name} has been returned. Please inspect it.`,
    },
    COMPLETED: {
      userId: rental.renterId,
      title: "All done!",
      message: depositInfo?.forfeited
        ? `${rental.tool.name} completed. Your security deposit was withheld: ${depositInfo.reason}.`
        : depositInfo?.ok
        ? `${rental.tool.name} completed. Your security deposit of Rs ${rental.securityDeposit} has been refunded.`
        : `${rental.tool.name} completed. Leave a review?`,
    },
    CANCELLED: {
      userId: actorRole === "VENDOR" ? rental.renterId : rental.tool.ownerId,
      type: "RENTAL_CANCELLED",
      title: "Booking cancelled",
      message: refundInfo?.ok
        ? `${rental.tool.name} booking was cancelled and a refund has been issued.`
        : `${rental.tool.name} booking was cancelled.`,
    },
  };

  const cfg = messages[newStatus];
  if (!cfg) return;

  try {
    await createNotification({
      userId: cfg.userId,
      type: cfg.type || "BOOKING_ACCEPTED",
      title: cfg.title,
      message: cfg.message,
      toolId: rental.toolId,
      rentalId: rental.id,
      dedupeKey: `status_${rental.id}_${newStatus}`,
    });
  } catch (e) {
    console.error("Status-change notification failed:", e);
  }
}

// Partial refund of only the deposit portion, separate from the full-order
// refund issued on cancellation.
async function issueDepositRefund(rental) {
  if (!rental.paymentIntentId) return { ok: false, reason: "missing_payment_intent" };
  try {
    const refund = await stripe.refunds.create({
      payment_intent: rental.paymentIntentId,
      amount: Math.round(rental.securityDeposit * 100),
    });
    return { ok: true, refundId: refund.id };
  } catch (e) {
    console.error(`Deposit refund failed for rental ${rental.id}:`, e.message);
    return { ok: false, reason: e.message };
  }
}
