import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";
import { createNotification } from "@/lib/notifications";

export async function POST(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const { reason } = await req.json().catch(() => ({}));

  const rental = await prisma.rental.findUnique({
    where: { id: params.id },
    include: { tool: true },
  });

  if (!rental || rental.tool.ownerId !== session.user.id) {
    return Response.json({ error: "Not your rental" }, { status: 403 });
  }
  if (rental.status !== "PENDING_VENDOR_ACCEPTANCE") {
    return Response.json({ error: "Invalid status" }, { status: 400 });
  }

  const updateData = {
    status: "CANCELLED",
    cancelledAt: new Date(),
    cancelReason: reason || "Rejected by provider",
  };

  if (rental.paymentStatus === "SUCCESS" && rental.paymentIntentId) {
    try {
      const refund = await stripe.refunds.create({ payment_intent: rental.paymentIntentId });
      updateData.paymentStatus = "REFUNDED";
      updateData.refundedAt = new Date();
      updateData.refundAmount = rental.totalAmount;
      updateData.refundId = refund.id;
    } catch (e) {
      console.error(`Refund failed while rejecting rental ${rental.id}:`, e.message);
    }
  }

  if (rental.transactionType === "BUY") {
    await prisma.tool.update({ where: { id: rental.toolId }, data: { isAvailable: true } });
  }

  await prisma.$transaction([
    prisma.rental.update({ where: { id: rental.id }, data: updateData }),
    prisma.rentalStatusHistory.create({
      data: {
        rentalId: rental.id,
        newStatus: "CANCELLED",
        oldStatus: rental.status,
        notes: reason || "Rejected by provider",
      },
    }),
  ]);

  try {
    await createNotification({
      userId: rental.renterId,
      type: "BOOKING_REJECTED",
      title: "Booking declined",
      message: `Your booking for ${rental.tool.name} was declined by the provider${
        updateData.paymentStatus === "REFUNDED" ? " and has been refunded." : "."
      }`,
      toolId: rental.toolId,
      rentalId: rental.id,
      dedupeKey: `status_${rental.id}_REJECTED`,
    });
  } catch (e) {
    console.error(e);
  }

  return Response.json({ success: true });
}
