import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { createNotification } from "@/lib/notifications";
import { DELIVERY_FEE_FLAT, calcRentalDaysCeil, commissionOn } from "@/lib/pricing";
import { validateCoupon, computeDiscount } from "@/lib/coupons";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const revalidate = 0;
export const fetchCache = "force-no-store";


// Rental statuses that mean "this tool is spoken for" for its date range,
// or (for BUY) that the item is no longer up for grabs.
const BLOCKING_STATUSES = [
  "PENDING_PAYMENT",
  "PAYMENT_SUCCESS",
  "PENDING_VENDOR_ACCEPTANCE",
  "ACCEPTED",
  "PREPARING",
  "READY",
  "OUT_FOR_DELIVERY",
  "ACTIVE",
];

function parseDateInput(body) {
  // Backwards compatible:
  // - Old clients send: startDate, endDate (date-only)
  // - New clients can send: startAt, endAt (date+time ISO or datetime-local converted)
  const startRaw = body.startAt || body.startDate;
  const endRaw = body.endAt || body.endDate;

  const start = new Date(startRaw);
  const end = new Date(endRaw);

  return { start, end, startRaw, endRaw };
}

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const rentals = await prisma.rental.findMany({
      where: {
        OR: [{ renterId: session.user.id }, { tool: { ownerId: session.user.id } }],
      },
      include: {
        tool: { include: { owner: { select: { id: true, name: true } } } },
        renter: { select: { id: true, name: true, email: true } },
        delivery: true,
      },
      orderBy: { createdAt: "desc" },
    });

    return Response.json(rentals);
  } catch (err) {
    console.error("GET /api/rentals error:", err);
    return Response.json({ error: err.message || "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json();
    const {
      toolId,
      pickupType = "PICKUP",
      deliveryAddress,
      transactionType = "RENT",
      couponCode,
    } = body;

    const isBuy = transactionType === "BUY";

    if (!toolId) {
      return Response.json({ error: "Missing required field: toolId" }, { status: 400 });
    }

    if (pickupType === "DELIVERY" && !deliveryAddress) {
      return Response.json(
        { error: "A delivery address is required for home delivery" },
        { status: 400 }
      );
    }

    // 1) Tool existence + owner status
    const tool = await prisma.tool.findUnique({
      where: { id: toolId },
      include: { owner: { select: { id: true, name: true, providerStatus: true } } },
    });

    if (!tool) return Response.json({ error: "Tool not found" }, { status: 404 });
    if (!tool.isAvailable) {
      return Response.json({ error: "This item is not currently available" }, { status: 400 });
    }
    if (tool.owner.providerStatus !== "APPROVED") {
      // Owner is no longer a verified provider (suspended/rejected) — block bookings.
      return Response.json(
        { error: "This item is temporarily unavailable from its provider" },
        { status: 400 }
      );
    }
    if (session.user.id === tool.ownerId) {
      return Response.json({ error: "You cannot book your own listing" }, { status: 400 });
    }

    let start, end, days;

    if (isBuy) {
      if (tool.salePrice == null || tool.salePrice <= 0) {
        return Response.json({ error: "This item is not available for purchase" }, { status: 400 });
      }
      // Purchases don't have a date range — use "now" as a placeholder so the
      // schema's non-null DateTime columns stay meaningful in history views.
      start = new Date();
      end = new Date();
      days = 1;
    } else {
      const { start: s, end: e, startRaw, endRaw } = parseDateInput(body);
      start = s;
      end = e;

      if (!startRaw || !endRaw) {
        return Response.json(
          { error: "Missing required fields: startDate/endDate or startAt/endAt" },
          { status: 400 }
        );
      }
      if (isNaN(start.getTime()) || isNaN(end.getTime())) {
        return Response.json({ error: "Invalid date/time format" }, { status: 400 });
      }
      if (end <= start) {
        return Response.json(
          { error: "Invalid date range (end must be after start)" },
          { status: 400 }
        );
      }
      if (start < new Date(Date.now() - 24 * 60 * 60 * 1000)) {
        return Response.json({ error: "Start date cannot be in the past" }, { status: 400 });
      }

      days = calcRentalDaysCeil(start, end);
    }

    // 2) Pricing
    const rentalAmount = isBuy ? tool.salePrice : days * tool.pricePerDay;
    const deliveryFee = pickupType === "DELIVERY" ? DELIVERY_FEE_FLAT : 0;
    const platformFee = commissionOn(rentalAmount);
    const securityDeposit = isBuy ? 0 : tool.securityDeposit ?? 0;

    let discountAmount = 0;
    let appliedCouponCode = null;
    if (couponCode) {
      const c = await validateCoupon(couponCode, rentalAmount);
      if (!c.ok) return Response.json({ error: c.error }, { status: 400 });
      discountAmount = computeDiscount(c.coupon, rentalAmount);
      appliedCouponCode = c.coupon.code;
    }
    const totalAmount = Math.max(0, rentalAmount - discountAmount + deliveryFee + platformFee + securityDeposit);

    // 3) Overlap / availability check + creation, inside one transaction to
    // shrink (not eliminate — see the webhook's second-pass cleanup) the
    // race window between two customers booking the same slot at once.
    const rental = await prisma.$transaction(async (tx) => {
      if (isBuy) {
        const conflict = await tx.rental.findFirst({
          where: { toolId, transactionType: "BUY", status: { in: BLOCKING_STATUSES } },
          select: { id: true },
        });
        if (conflict) {
          throw Object.assign(new Error("This item has already been purchased or is being purchased."), {
            statusCode: 409,
          });
        }
      } else {
        const overlapping = await tx.rental.findFirst({
          where: {
            toolId,
            startDate: { lte: end },
            endDate: { gte: start },
            status: { in: BLOCKING_STATUSES },
          },
          select: { id: true },
        });
        if (overlapping) {
          throw Object.assign(new Error("This item is unavailable for the selected dates."), { statusCode: 409 });
        }
        const blocked = await tx.blockedDate.findFirst({
          where: { toolId, startDate: { lte: end }, endDate: { gte: start } },
          select: { id: true },
        });
        if (blocked) {
          throw Object.assign(new Error("This item is unavailable for the selected dates."), { statusCode: 409 });
        }
      }

      if (appliedCouponCode) {
        // Re-check inside the transaction so the last redemption of a
        // limited coupon can't be used twice at once.
        const c = await validateCoupon(appliedCouponCode, rentalAmount, tx);
        if (!c.ok) throw Object.assign(new Error(c.error), { statusCode: 409 });
        await tx.coupon.update({ where: { id: c.coupon.id }, data: { usedCount: { increment: 1 } } });
      }

      return tx.rental.create({
        data: {
          toolId,
          renterId: session.user.id,
          transactionType: isBuy ? "BUY" : "RENT",
          rentalAmount,
          deliveryFee,
          platformFee,
          securityDeposit,
          couponCode: appliedCouponCode,
          discountAmount,
          totalAmount,
          startDate: start,
          endDate: end,
          status: "PENDING_PAYMENT",
          paymentStatus: "PENDING",
          pickupType,
          deliveryAddress: deliveryAddress || null,
        },
      });
    });

    // 4) Notifications (safe: never break booking if this fails)
    try {
      await createNotification({
        userId: tool.ownerId,
        type: "BOOKING_REQUESTED",
        title: isBuy ? "New purchase request" : "New rental request",
        message: isBuy
          ? `${session.user.name || "A customer"} wants to buy ${tool.name}.`
          : `${session.user.name || "A customer"} requested ${tool.name} for ${days} day(s).`,
        toolId: tool.id,
        rentalId: rental.id,
        dedupeKey: `owner_rental_request_${rental.id}`,
      });
    } catch (e) {
      console.error("Owner notification failed:", e);
    }

    return Response.json(
      {
        success: true,
        rentalId: rental.id,
        totalAmount,
        breakdown: {
          transactionType: isBuy ? "BUY" : "RENT",
          days: isBuy ? null : days,
          pricePerDay: isBuy ? null : tool.pricePerDay,
          salePrice: isBuy ? tool.salePrice : null,
          rentalAmount,
          deliveryFee,
          platformFee,
          securityDeposit,
          totalAmount,
          pickupType,
        },
      },
      { status: 201 }
    );
  } catch (err) {
    if (err?.statusCode === 409) {
      return Response.json({ error: err.message }, { status: 409 });
    }
    console.error("POST /api/rentals error:", err);
    return Response.json({ error: err.message || "Internal Server Error" }, { status: 500 });
  }
}
