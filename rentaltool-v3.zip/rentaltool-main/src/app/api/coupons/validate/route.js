import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { validateCoupon, computeDiscount } from "@/lib/coupons";

export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { code, orderAmount } = await req.json();
  if (!code || orderAmount == null) return Response.json({ error: "code and orderAmount are required" }, { status: 400 });

  const result = await validateCoupon(code, orderAmount);
  if (!result.ok) return Response.json({ error: result.error }, { status: 400 });
  return Response.json({
    valid: true,
    code: result.coupon.code,
    discountAmount: computeDiscount(result.coupon, orderAmount),
  });
}
