import { prisma } from "@/lib/prisma";
import { NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth"; // Adjust import path

export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { rentalId, rating, comment } = await req.json();

  // Check if rental belongs to user and is completed
  const rental = await prisma.rental.findUnique({
    where: { id: rentalId },
    include: { tool: true },
  });

  if (!rental || rental.renterId !== session.user.id || rental.status !== "COMPLETED") {
    return NextResponse.json({ error: "You cannot review this rental" }, { status: 403 });
  }

  // Check if review already exists
  const existing = await prisma.review.findUnique({ where: { rentalId } });
  if (existing) return NextResponse.json({ error: "Review already submitted" }, { status: 400 });

  const review = await prisma.review.create({
    data: {
      rentalId,
      toolId: rental.toolId,
      userId: session.user.id,
      rating: parseInt(rating),
      comment,
    },
  });

  // Update tool rating average
  const toolReviews = await prisma.review.aggregate({
    where: { toolId: rental.toolId },
    _avg: { rating: true },
  });

  await prisma.tool.update({
    where: { id: rental.toolId },
    data: { rating: toolReviews._avg.rating || 0 },
  });

  return NextResponse.json(review, { status: 201 });
}
