import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export const runtime = "nodejs";

// Uploads are stored as data: URIs in Postgres so this works with zero
// external config. For production scale, swap this body for an upload to
// S3 / Cloudinary / Vercel Blob and keep returning { url }.
const MAX_BYTES = 4.5 * 1024 * 1024;
const ALLOWED = ["image/jpeg", "image/png", "image/webp", "image/gif"];

export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  let form;
  try {
    form = await req.formData();
  } catch {
    return Response.json({ error: "Expected multipart/form-data with a 'file' field" }, { status: 400 });
  }
  const file = form.get("file");
  if (!file || typeof file === "string") return Response.json({ error: "No file provided" }, { status: 400 });
  if (!ALLOWED.includes(file.type)) return Response.json({ error: "Only JPEG, PNG, WEBP or GIF images are allowed" }, { status: 400 });
  if (file.size > MAX_BYTES) return Response.json({ error: "Image too large (max 4.5MB)" }, { status: 400 });

  const base64 = Buffer.from(await file.arrayBuffer()).toString("base64");
  return Response.json({ url: `data:${file.type};base64,${base64}` });
}
