import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { stripe } from "@/lib/stripe";

const CURRENCY = process.env.STRIPE_CURRENCY || "inr";
// Stripe's `upi` payment method is only available on Indian Stripe accounts.
// Toggle this off (e.g. via env) if the connected account isn't India-based.
const ENABLE_UPI = process.env.STRIPE_ENABLE_UPI !== "false";

export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const { rentalId } = await req.json();
  if (!rentalId) return Response.json({ error: "Missing rentalId" }, { status: 400 });

  const rental = await prisma.rental.findUnique({
    where: { id: rentalId },
    include: { tool: true },
  });

  if (!rental || rental.renterId !== session.user.id) {
    return Response.json({ error: "Rental not found" }, { status: 404 });
  }

  if (rental.status !== "PENDING_PAYMENT") {
    return Response.json({ error: "This booking has already been paid or is no longer payable." }, { status: 400 });
  }

  // Never trust a client-supplied amount — always charge exactly what the
  // server computed and stored when the rental was created.
  const description =
    rental.transactionType === "BUY"
      ? `Purchase: ${rental.tool.name}`
      : `Rental: ${rental.tool.name} (${new Date(rental.startDate).toLocaleDateString()} – ${new Date(
          rental.endDate
        ).toLocaleDateString()})`;

  const paymentMethodTypes = ["card"];
  if (ENABLE_UPI) paymentMethodTypes.push("upi");

  let checkout;
  try {
    checkout = await stripe.checkout.sessions.create({
      payment_method_types: paymentMethodTypes,
      line_items: [
        {
          price_data: {
            currency: CURRENCY,
            product_data: { name: rental.tool.name, description },
            unit_amount: Math.round(rental.totalAmount * 100),
          },
          quantity: 1,
        },
      ],
      mode: "payment",
      customer_email: session.user.email || undefined,
      success_url: `${process.env.NEXTAUTH_URL}/rentals/${rental.id}?success=true`,
      cancel_url: `${process.env.NEXTAUTH_URL}/tools/${rental.toolId}?canceled=true`,
      metadata: { rentalId: rental.id, transactionType: rental.transactionType },
      expires_at: Math.floor(Date.now() / 1000) + 30 * 60, // 30 min hold
    });
  } catch (e) {
    console.error("Stripe checkout session creation failed:", e.message);
    return Response.json({ error: "Could not start payment. Please try again." }, { status: 502 });
  }

  await prisma.rental.update({
    where: { id: rental.id },
    data: { checkoutSessionId: checkout.id },
  });

  return Response.json({ url: checkout.url });
}
