import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export async function PATCH(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return new Response("Unauthorized", { status: 401 });

  const notification = await prisma.notification.findUnique({
    where: { id: params.id },
  });

  if (!notification) return new Response("Not Found", { status: 404 });

  if (notification.userId !== session.user.id) {
    return new Response("Forbidden", { status: 403 });
  }

  const updated = await prisma.notification.update({
    where: { id: params.id },
    data: { read: true },
  });

  return Response.json(updated);
}
