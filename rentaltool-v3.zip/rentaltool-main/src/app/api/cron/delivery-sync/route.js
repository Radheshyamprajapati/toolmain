import { prisma } from "@/lib/prisma";
import { nextSimulatedStatus, appendDeliveryEvent } from "@/lib/delivery";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const revalidate = 0;

// In production, a real delivery partner calls POST /api/delivery/webhook
// whenever a shipment's status changes. This route stands in for that —
// it's what a demo/staging environment polls (via Vercel Cron or manually)
// to make in-flight shipments visibly progress without a real courier.
function isAuthorizedCron(req) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return true;
  const auth = req.headers.get("authorization");
  return auth === `Bearer ${secret}`;
}

const EVENT_NOTES = {
  PICKED_UP: "Package picked up from provider",
  IN_TRANSIT: "In transit to destination",
  OUT_FOR_DELIVERY: "Out for delivery",
  DELIVERED: "Delivered to customer",
};

export async function GET(req) {
  if (!isAuthorizedCron(req)) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const inFlight = await prisma.delivery.findMany({
    where: { status: { notIn: ["DELIVERED", "RETURN_COMPLETED", "FAILED"] } },
  });

  let advanced = 0;
  for (const delivery of inFlight) {
    const next = nextSimulatedStatus(delivery);
    if (!next) continue;
    await appendDeliveryEvent(delivery.id, next, EVENT_NOTES[next] || `Status: ${next}`);
    advanced++;
  }

  return Response.json({ ok: true, checked: inFlight.length, advanced });
}
