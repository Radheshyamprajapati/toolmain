export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const revalidate = 0;
export const fetchCache = "force-no-store";

import { prisma } from "@/lib/prisma";
import { createNotification } from "@/lib/notifications";

function isAuthorizedCron(req) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return true; // no secret configured — allow (e.g. local dev)
  const auth = req.headers.get("authorization");
  return auth === `Bearer ${secret}`;
}

export async function GET(req) {
  if (!isAuthorizedCron(req)) {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const activeRentals = await prisma.rental.findMany({
    where: { status: "ACTIVE", transactionType: "RENT" },
    include: { tool: true, renter: true },
  });

  const now = new Date();

  for (const rental of activeRentals) {
    const end = new Date(rental.endDate);
    const diffMs = end.getTime() - now.getTime();
    const hoursLeft = diffMs / (1000 * 60 * 60);

    if (diffMs <= 0) {
      // Tool has expired
      await createNotification({
        userId: rental.renterId,
        type: "EXPIRED",
        title: "Tool expired",
        message: `${rental.tool.name} has expired.`,
        toolId: rental.toolId,
        rentalId: rental.id,
        dedupeKey: `expired_${rental.id}_${rental.renterId}`,
      });
      continue;
    }

    // Send the nearest reminder only once
    const reminderLevels = [
      { limit: 0.25, key: "15m", label: "15 minutes" },
      { limit: 1, key: "1h", label: "1 hour" },
      { limit: 24, key: "24h", label: "24 hours" },
    ];

    const level = reminderLevels.find((item) => hoursLeft <= item.limit);

    if (level) {
      await createNotification({
        userId: rental.renterId,
        type: "EXPIRY_REMINDER",
        title: "Rental expiry reminder",
        message: `Reminder: Your rental of ${rental.tool.name} expires in ${level.label}.`,
        toolId: rental.toolId,
        rentalId: rental.id,
        dedupeKey: `expiry_reminder_${rental.id}_${rental.renterId}_${level.key}`,
      });
    }
  }

  return Response.json({ ok: true, processed: activeRentals.length });
}
