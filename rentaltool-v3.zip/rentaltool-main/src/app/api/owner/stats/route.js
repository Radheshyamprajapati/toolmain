import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { prisma } from "@/lib/prisma";

export const dynamic = "force-dynamic";

export async function GET() {
  const session = await getServerSession(authOptions);
  if (!session || session.user.role !== "TRADESMAN") {
    return Response.json({ error: "Unauthorized" }, { status: 401 });
  }

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const startOfWeek = new Date(startOfDay);
  startOfWeek.setDate(startOfDay.getDate() - startOfDay.getDay());
  const startOfMonth = new Date(startOfDay.getFullYear(), startOfDay.getMonth(), 1);

  async function earningsSince(date) {
    const result = await prisma.rental.aggregate({
      where: {
        status: "COMPLETED",
        tool: { ownerId: session.user.id },
        completedAt: { gte: date },
      },
      _sum: { totalAmount: true },
    });
    return result._sum.totalAmount || 0;
  }

  const [daily, weekly, monthly, total, pendingApproval] = await Promise.all([
    earningsSince(startOfDay),
    earningsSince(startOfWeek),
    earningsSince(startOfMonth),
    prisma.rental
      .aggregate({
        where: { status: "COMPLETED", tool: { ownerId: session.user.id } },
        _sum: { totalAmount: true },
      })
      .then((r) => r._sum.totalAmount || 0),
    prisma.rental.count({
      where: { status: "PENDING_VENDOR_ACCEPTANCE", tool: { ownerId: session.user.id } },
    }),
  ]);

  return Response.json({
    daily,
    weekly,
    monthly,
    total,
    pendingApproval,
    providerStatus: session.user.providerStatus,
  });
}
