import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import {
  isValidGroup,
  categoriesForGroup,
  isValidEventOccasion,
} from "@/lib/categories";

function normalizeStringArray(val) {
  // Accept: array of strings
  // Reject: anything else -> null
  if (!val) return null;
  if (Array.isArray(val)) {
    return val
      .map((x) => String(x).trim())
      .filter(Boolean);
  }
  return null;
}

export async function GET(req) {
  try {
    const { searchParams } = new URL(req.url);
    const group = searchParams.get("group");
    const category = searchParams.get("category");
    const occasion = searchParams.get("occasion"); // events only
    const q = searchParams.get("q");

    const where = {};

    // Group filtering
    if (group && isValidGroup(group)) {
      where.categoryGroup = group;
    }

    // Category filtering (item-type)
    if (category) where.category = category;

    // Occasion filtering (EVENTS)
    if (occasion && isValidEventOccasion(occasion)) {
      where.eventOccasion = occasion;
    }

    // Search
    if (q) {
      where.OR = [
        { name: { contains: q, mode: "insensitive" } },
        { description: { contains: q, mode: "insensitive" } },
        { location: { contains: q, mode: "insensitive" } },
        { category: { contains: q, mode: "insensitive" } },
        { eventOccasion: { contains: q, mode: "insensitive" } },
      ];
    }

    const tools = await prisma.tool.findMany({
      where,
      include: { owner: { select: { id: true, name: true, avatar: true } } },
      orderBy: { createdAt: "desc" },
    });

    return Response.json(tools);
  } catch (e) {
    console.error("GET /api/tools error:", e);
    return Response.json({ error: e.message || "Internal Server Error" }, { status: 500 });
  }
}

export async function POST(req) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  if (session.user.role !== "TRADESMAN") {
    return Response.json(
      { error: "Only registered equipment providers can list tools" },
      { status: 403 }
    );
  }
  if (session.user.providerStatus !== "APPROVED") {
    return Response.json(
      {
        error:
          session.user.providerStatus === "PENDING"
            ? "Your provider application is still under review. You'll be able to list tools once it's approved."
            : "You're not an approved provider yet. Please contact support.",
      },
      { status: 403 }
    );
  }

  try {
    const body = await req.json();

    const group = isValidGroup(body.categoryGroup) ? body.categoryGroup : "TOOLS";
    const allowed = categoriesForGroup(group);

    if (!body.category || (allowed.length && !allowed.includes(body.category))) {
      return Response.json(
        { error: "Invalid category for selected group" },
        { status: 400 }
      );
    }

    // For EVENTS group, require eventOccasion
    if (group === "EVENTS" && !isValidEventOccasion(body.eventOccasion)) {
      return Response.json(
        { error: "Invalid or missing event occasion" },
        { status: 400 }
      );
    }

    // Optional: for EVENTS, require some decor info (soft validation)
    // Keep it non-breaking: only enforce minimally.
    if (group === "EVENTS") {
      const included = normalizeStringArray(body.includedItems) || [];
      if (!body.setSize && included.length === 0) {
        return Response.json(
          { error: "For Events listings, provide set size or included items." },
          { status: 400 }
        );
      }
    }

    const tool = await prisma.tool.create({
      data: {
        name: body.name,
        description: body.description,

        categoryGroup: group,
        category: body.category,
        eventOccasion: group === "EVENTS" ? body.eventOccasion : null,

        pricePerDay: Number(body.pricePerDay),
        salePrice: body.salePrice ? Number(body.salePrice) : null,
        securityDeposit: body.securityDeposit ? Number(body.securityDeposit) : 0,

        image: body.image || null,
        location: body.location,
        latitude: body.latitude ? Number(body.latitude) : null,
        longitude: body.longitude ? Number(body.longitude) : null,

        condition: body.condition || "Good",
        isAvailable: body.isAvailable ?? true,
        rating: body.rating ?? 0,

        // ✅ Decor set fields (optional, mainly for EVENTS)
        setSize: body.setSize || null,
        includedItems: normalizeStringArray(body.includedItems),
        requiredItems: normalizeStringArray(body.requiredItems),
        setupInstructions: body.setupInstructions || null,

        ownerId: session.user.id,
      },
      include: { owner: { select: { id: true, name: true, avatar: true } } },
    });

    return Response.json(tool, { status: 201 });
  } catch (e) {
    console.error("POST /api/tools error:", e);
    return Response.json({ error: e.message || "Internal Server Error" }, { status: 500 });
  }
}
