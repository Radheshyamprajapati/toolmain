import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

function normalizeStringArray(val) {
  if (val == null) return null;
  if (!Array.isArray(val)) return null;
  return val.map((x) => String(x).trim()).filter(Boolean);
}

function toNumberOrNull(val) {
  if (val === "" || val === null || val === undefined) return null;
  const n = Number(val);
  return Number.isFinite(n) ? n : null;
}

function toNumberOrDefault(val, def) {
  const n = Number(val);
  return Number.isFinite(n) ? n : def;
}

export async function GET(req, { params }) {
  try {
    const tool = await prisma.tool.findUnique({
      where: { id: params.id },
      include: { owner: { select: { id: true, name: true, avatar: true } } },
    });

    if (!tool) return Response.json({ error: "Not Found" }, { status: 404 });
    return Response.json(tool);
  } catch (e) {
    console.error("GET /api/tools/[id] error:", e);
    return Response.json({ error: e.message || "Internal Server Error" }, { status: 500 });
  }
}

export async function PUT(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const body = await req.json();

    const existing = await prisma.tool.findUnique({ where: { id: params.id } });
    if (!existing) return Response.json({ error: "Not Found" }, { status: 404 });

    if (existing.ownerId !== session.user.id || session.user.role !== "TRADESMAN" || session.user.providerStatus !== "APPROVED") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    // Validate required numeric if provided
    if (body.pricePerDay !== undefined) {
      const ppd = Number(body.pricePerDay);
      if (!Number.isFinite(ppd) || ppd < 0) {
        return Response.json({ error: "Invalid pricePerDay" }, { status: 400 });
      }
    }

    const updated = await prisma.tool.update({
      where: { id: params.id },
      data: {
        // Basic fields (keep existing if not provided)
        name: body.name ?? existing.name,
        description: body.description ?? existing.description,
        category: body.category ?? existing.category,
        categoryGroup: body.categoryGroup ?? existing.categoryGroup,
        eventOccasion: body.eventOccasion ?? existing.eventOccasion,

        // Pricing
        pricePerDay:
          body.pricePerDay !== undefined
            ? toNumberOrDefault(body.pricePerDay, existing.pricePerDay)
            : existing.pricePerDay,

        // Important: allow 0, and treat "" as null
        salePrice:
          body.salePrice !== undefined ? toNumberOrNull(body.salePrice) : existing.salePrice,

        securityDeposit:
          body.securityDeposit !== undefined
            ? toNumberOrDefault(body.securityDeposit, existing.securityDeposit ?? 0)
            : (existing.securityDeposit ?? 0),

        // ✅ Decor fields
        setSize: body.setSize !== undefined ? (body.setSize || null) : existing.setSize,
        includedItems:
          body.includedItems !== undefined
            ? normalizeStringArray(body.includedItems)
            : existing.includedItems,
        requiredItems:
          body.requiredItems !== undefined
            ? normalizeStringArray(body.requiredItems)
            : existing.requiredItems,
        setupInstructions:
          body.setupInstructions !== undefined
            ? (body.setupInstructions || null)
            : existing.setupInstructions,

        // Media + location
        image: body.image !== undefined ? (body.image || null) : existing.image,
        location: body.location ?? existing.location,
        latitude:
          body.latitude !== undefined ? toNumberOrNull(body.latitude) : existing.latitude,
        longitude:
          body.longitude !== undefined ? toNumberOrNull(body.longitude) : existing.longitude,

        condition: body.condition ?? existing.condition,
        isAvailable:
          body.isAvailable !== undefined ? Boolean(body.isAvailable) : existing.isAvailable,
      },
      include: { owner: { select: { id: true, name: true, avatar: true } } },
    });

    return Response.json(updated);
  } catch (e) {
    console.error("PUT /api/tools/[id] error:", e);
    return Response.json({ error: e.message || "Internal Server Error" }, { status: 500 });
  }
}

export async function DELETE(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  try {
    const existing = await prisma.tool.findUnique({ where: { id: params.id } });
    if (!existing) return Response.json({ error: "Not Found" }, { status: 404 });

    if (existing.ownerId !== session.user.id || session.user.role !== "TRADESMAN" || session.user.providerStatus !== "APPROVED") {
      return Response.json({ error: "Forbidden" }, { status: 403 });
    }

    const activeRentalCount = await prisma.rental.count({
      where: {
        toolId: params.id,
        status: {
          in: [
            "PENDING_PAYMENT",
            "PAYMENT_SUCCESS",
            "PENDING_VENDOR_ACCEPTANCE",
            "ACCEPTED",
            "PREPARING",
            "READY",
            "OUT_FOR_DELIVERY",
            "ACTIVE",
            "RETURN_REQUESTED",
            "RETURNED",
            "INSPECTION",
          ],
        },
      },
    });
    if (activeRentalCount > 0) {
      return Response.json(
        { error: "This item has active or in-progress bookings and can't be deleted. Mark it unavailable instead." },
        { status: 409 }
      );
    }

    await prisma.tool.delete({ where: { id: params.id } });
    return new Response(null, { status: 204 });
  } catch (e) {
    console.error("DELETE /api/tools/[id] error:", e);
    return Response.json({ error: e.message || "Internal Server Error" }, { status: 500 });
  }
}
