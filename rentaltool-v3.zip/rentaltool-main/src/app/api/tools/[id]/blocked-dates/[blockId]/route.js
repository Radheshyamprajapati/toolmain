import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function DELETE(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const block = await prisma.blockedDate.findUnique({ where: { id: params.blockId }, include: { tool: true } });
  if (!block || block.toolId !== params.id) return Response.json({ error: "Not found" }, { status: 404 });
  if (block.tool.ownerId !== session.user.id || session.user.role !== "TRADESMAN" || session.user.providerStatus !== "APPROVED") {
    return Response.json({ error: "Forbidden" }, { status: 403 });
  }
  await prisma.blockedDate.delete({ where: { id: params.blockId } });
  return new Response(null, { status: 204 });
}
