import { prisma } from "@/lib/prisma";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

const BLOCKING = ["PENDING_PAYMENT","PAYMENT_SUCCESS","PENDING_VENDOR_ACCEPTANCE","ACCEPTED","PREPARING","READY","OUT_FOR_DELIVERY","ACTIVE"];

// Public: lets the booking calendar grey out unavailable dates.
export async function GET(req, { params }) {
  const [booked, manual] = await Promise.all([
    prisma.rental.findMany({
      where: { toolId: params.id, transactionType: "RENT", status: { in: BLOCKING } },
      select: { startDate: true, endDate: true },
    }),
    prisma.blockedDate.findMany({
      where: { toolId: params.id },
      select: { id: true, startDate: true, endDate: true, reason: true },
    }),
  ]);
  return Response.json({ booked, manual });
}

// Owner-only (approved provider). Admins cannot manage listings.
export async function POST(req, { params }) {
  const session = await getServerSession(authOptions);
  if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const tool = await prisma.tool.findUnique({ where: { id: params.id } });
  if (!tool) return Response.json({ error: "Not found" }, { status: 404 });
  if (tool.ownerId !== session.user.id || session.user.role !== "TRADESMAN" || session.user.providerStatus !== "APPROVED") {
    return Response.json({ error: "Forbidden" }, { status: 403 });
  }

  const { startDate, endDate, reason } = await req.json();
  const start = new Date(startDate);
  const end = new Date(endDate);
  if (isNaN(start.getTime()) || isNaN(end.getTime()) || end < start) {
    return Response.json({ error: "Invalid date range" }, { status: 400 });
  }
  const block = await prisma.blockedDate.create({
    data: { toolId: params.id, startDate: start, endDate: end, reason: reason || null },
  });
  return Response.json(block, { status: 201 });
}
